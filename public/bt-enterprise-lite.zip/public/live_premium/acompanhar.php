<?php
declare(strict_types=1);

require_once __DIR__ . '/../../bootstrap.php';
use BTQueue\Core\Database;
use BTQueue\Core\Auth;

// [SaaS] Resolve o Tenant Autenticado
$tenantId = Auth::tenantId();
if ($tenantId <= 0) {
    die("<h1>❌ Unidade não identificada via subdomínio.</h1>");
}

$uuid = $_GET['uuid'] ?? '';

$config = [];
try {
    $linhas = Database::fetchAll("SELECT chave, valor FROM configuracoes WHERE tenant_id = ?", [$tenantId]);
    foreach ($linhas as $linha) { $config[$linha['chave']] = $linha['valor']; }
} catch (Exception $e) {}

$empresa = $config['empresa'] ?? 'BT Queue Enterprise';
$promo_logo = $config['promo_logo'] ?? '';
$promo_campanha = $config['promo_campanha'] ?? '';

// CÁLCULO DE BASE_URL ATÔMICA
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$baseUrl = $protocol . $_SERVER['HTTP_HOST'] . str_replace('live_premium/acompanhar.php', '', $_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>Acompanhamento - <?= htmlspecialchars($empresa) ?></title>
    <link rel="stylesheet" href="assets/css/premium.css?v=1.2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body class="noc-theme">

<div id="app" class="live-container">
    <header class="header-premium">
        <!-- BARRA DE DESBLOQUEIO DE ÁUDIO -->
        <div id="audio-unlock" class="audio-unlock-bar animate__animated animate__fadeInDown" style="display:none;" onclick="BT.tracker.unlockAudio()">
            <i class="fa-solid fa-volume-high"></i> CLIQUE AQUI PARA ATIVAR O SOM
        </div>
        <?php
            $logoUrl = null;
            if (!empty($promo_logo)) {
                $logoUrl = $baseUrl . ltrim($promo_logo, '/');
               $logoPath = __DIR__ . '/../' . ltrim($promo_logo, '/');

               if (is_file($logoPath)) {
                   $logoUrl .= '?v=' . filemtime($logoPath);
               }
            }
        ?>
        <?php if ($logoUrl): ?>
            <img src="<?= $logoUrl ?>" alt="Logo" style="max-height: 100px; max-width: 80%; object-fit: contain; margin-bottom: 15px;">
        <?php else: ?>
            <i class="fa-solid fa-print"></i>
        <?php endif; ?>
        <h1>Sua Senha</h1>
        <p>Acompanhe em tempo real</p>
    </header>

    <main>
        <!-- CONTEÚDO DINÂMICO: Múltiplas Senhas -->
        <div id="tickets-container" class="animate__animated animate__fadeIn">
            <div style="padding: 100px 20px; text-align: center; color: var(--text2);">
                <i class="fa-solid fa-circle-notch fa-spin" style="font-size: 40px; color: var(--secondary); margin-bottom: 20px;"></i>
                <p>Sincronizando seus atendimentos...</p>
            </div>
        </div>

        <!-- ÁREA DE PROMOÇÕES -->
        <div class="promo-premium-container">
            <div id="promo-display" class="promo-item-row">
                <img id="promo-img" src="" class="promo-item-img" onerror="this.style.display='none'">
                <div class="promo-item-info">
                    <h4 id="promo-title">...</h4>
                    <div id="promo-price" class="promo-item-price"></div>
                    <p id="promo-desc" class="promo-item-desc"></p>
                </div>
            </div>
            <div class="promo-banner-red">
                <span>⚡ OFERTAS IMPERDÍVEIS</span>
            </div>
        </div>

        <!-- BOTÃO ADICIONAL DIAMOND v2.4.3 (v2.8.9: Movido para baixo das promoções) -->
        <div style="padding:0 25px 30px; margin-top:20px;">
            <button onclick="BT.tracker.backToEmitter()" class="bt-button" style="width:100%; background:var(--sidebar); color:white; border:1px solid var(--border); padding:20px; font-weight:bold; border-radius:15px; display:flex; align-items:center; justify-content:center; gap:10px;">
                <i class="fa-solid fa-plus-circle" style="color:var(--accent);"></i> RETIRAR OUTRA SENHA
            </button>
        </div>

        <!-- NOVO BLOCO: CAMPANHA (Rodapé Solto) -->
        <?php if (!empty($promo_campanha)): ?>
        <?php
            $campanhaUrl = $baseUrl . ltrim($promo_campanha, '/');

            $campanhaPath = __DIR__ . '/../' . ltrim($promo_campanha, '/');

            if (is_file($campanhaPath)) {
                $campanhaUrl .= '?v=' . filemtime($campanhaPath);
            }
        ?>
        <div style="width:100%; margin-top:20px; border-radius:25px; overflow:hidden; box-shadow:var(--shadow-premium); background:var(--card); border:1px solid var(--border); padding:10px;">
            <img src="<?= htmlspecialchars($campanhaUrl) ?>" alt="Campanha" style="width:100%; border-radius:15px; display:block;">
        </div>
        <?php endif; ?>

    </main>

    <footer class="footer-signature" style="padding-bottom: 40px;">
        <p>Desenvolvido por</p>
        <img src="https://api.brandaotech.com.br/uploads/logo/logo.png" alt="Brandão Tech" style="margin-bottom: 15px;">
        <div style="display:flex; justify-content:center; gap:15px; margin-top:10px;">
            <a href="https://api.brandaotech.com.br/registrar.php" target="_blank" style="color:var(--secondary); font-size:11px; font-weight:bold; text-decoration:none; text-transform:uppercase; letter-spacing:1px; border:1px solid var(--border); padding:8px 15px; border-radius:10px; background:rgba(255,255,255,0.02);">
                <i class="fa-solid fa-rocket"></i> Solicitar Ativação SaaS
            </a>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
<script src="../assets/js/api.js?v=4.8"></script>
<script src="assets/js/tracker.js?v=5.7.4"></script>
</body>
</html>
