/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.20-12.3.3-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: bt_enterprise_saas
-- ------------------------------------------------------
-- Server version	12.3.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `agenda_bloqueios`
--

DROP TABLE IF EXISTS `agenda_bloqueios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_bloqueios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_fim` time DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_bloqueios_tenant` (`tenant_id`),
  CONSTRAINT `fk_bloqueios_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_bloqueios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_bloqueios` WRITE;
/*!40000 ALTER TABLE `agenda_bloqueios` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_bloqueios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agenda_regras`
--

DROP TABLE IF EXISTS `agenda_regras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_regras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `dia_semana` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `duracao_slot` int(11) DEFAULT 30,
  `liberacao_dia_semana` int(11) DEFAULT NULL,
  `liberacao_hora_inicio` time DEFAULT '00:00:00',
  `liberacao_hora_fim` time DEFAULT '23:59:59',
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_agenda_tenant` (`tenant_id`),
  KEY `fk_agenda_op` (`operador_id`),
  CONSTRAINT `fk_agenda_op` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agenda_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_regras`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_regras` WRITE;
/*!40000 ALTER TABLE `agenda_regras` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_regras` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agenda_suspensoes`
--

DROP TABLE IF EXISTS `agenda_suspensoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_suspensoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `identificador` varchar(100) NOT NULL,
  `motivo` text DEFAULT NULL,
  `data_fim` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_identificador` (`tenant_id`,`identificador`),
  CONSTRAINT `fk_suspensoes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_suspensoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_suspensoes` WRITE;
/*!40000 ALTER TABLE `agenda_suspensoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_suspensoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `atividades`
--

DROP TABLE IF EXISTS `atividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `tipo` varchar(20) DEFAULT 'INFO',
  `nivel` varchar(20) DEFAULT 'INFO',
  `categoria` varchar(50) DEFAULT 'SYSTEM',
  `mensagem` text NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `data_criacao` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_atividades_tenant` (`tenant_id`),
  KEY `idx_atividades_data` (`data_criacao`),
  CONSTRAINT `fk_atividades_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividades`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `atividades` WRITE;
/*!40000 ALTER TABLE `atividades` DISABLE KEYS */;
INSERT INTO `atividades` VALUES
(1,30,'INFO','INFO','FILA','Senha AGD001 chamada para Babrber Ricardo','Ricardo Brandão',NULL,'2026-08-22 11:17:16'),
(2,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-22 13:05:23'),
(3,30,'INFO','INFO','FILA','Senha JO001 chamada para Babrber João','JOÃO',NULL,'2026-08-22 13:06:47'),
(4,30,'INFO','INFO','FILA','Senha AGD003 chamada para Babrber João','JOÃO',NULL,'2026-08-22 13:18:03');
/*!40000 ALTER TABLE `atividades` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `evento` varchar(100) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `detalhes` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_auditoria_tenant` (`tenant_id`),
  CONSTRAINT `fk_auditoria_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `uuid` varchar(100) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `documento` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ATIVO',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fk_clientes_tenant` (`tenant_id`),
  CONSTRAINT `fk_clientes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `configuracoes`
--

DROP TABLE IF EXISTS `configuracoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `chave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `tipo` varchar(20) DEFAULT 'STRING',
  `descricao` text DEFAULT NULL,
  `editavel` tinyint(1) DEFAULT 1,
  `label_cliente` varchar(50) DEFAULT 'Paciente',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_chave` (`tenant_id`,`chave`),
  CONSTRAINT `fk_config_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=169925 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `configuracoes` WRITE;
/*!40000 ALTER TABLE `configuracoes` DISABLE KEYS */;
INSERT INTO `configuracoes` VALUES
(140620,30,'master_url','http://api.brandaotech.com.br:8080/api/v1/sync.php','STRING',NULL,1,'Paciente','2026-08-22 09:49:19'),
(140621,30,'uuid','5579fd18-b48e-473e-a6e1-fb3cf1335700','STRING',NULL,1,'Paciente','2026-08-22 09:49:19'),
(140622,30,'token','1C3E5CE9B707A09D1A80A33D87C1BF30A5F7D05F68D10E628365A99A52AEF125','STRING',NULL,1,'Paciente','2026-08-22 09:49:19'),
(145843,30,'app_name','BT Queue Enterprise','STRING','Nome da aplicação local',1,'Paciente','2026-08-22 10:03:43'),
(145844,30,'offline_limit_days','7','INT','Dias permitidos de operação sem sincronização',1,'Paciente','2026-08-22 10:03:43'),
(145845,30,'printer_name','BT_TICKET','STRING','Nome da impressora compartilhada no Windows',1,'Paciente','2026-08-22 10:03:43'),
(145846,30,'integration_token','CEF3504AC887599D03C07639D5C90D63','STRING','Token de Segurança para Chamadas via API Externa',1,'Paciente','2026-08-22 10:03:43'),
(145847,30,'qr_security_salt','bf3f736fa4c0024aca6a87317277fd93','STRING','Chave secreta para validação de QR Code dinâmico',1,'Paciente','2026-08-22 10:03:43'),
(145851,30,'feature_max_devices','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145852,30,'feature_voice_enabled','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145853,30,'feature_custom_branding','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145854,30,'feature_reports','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145855,30,'feature_multi_ticket','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145856,30,'feature_hybrid_scheduling','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145857,30,'modo','cloud','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145858,30,'url_local','http://192.168.100.245','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145859,30,'url_publica','http://lite.brandaotech.com.br:8120','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145860,30,'whatsapp','','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145861,30,'instagram','','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145862,30,'slogan','','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145863,30,'local_print_ip','192.168.100.126','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145865,30,'opening_time','00:00','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145866,30,'closing_time','23:59','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145868,30,'promo_campanha','uploads/logo_campanha.png','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145870,30,'label_cliente','Cliente','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145877,30,'mercadopago_token','','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145878,30,'pix_chave_estatica','71991077018','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145879,30,'mercadopago_test_mode','0','STRING',NULL,1,'Paciente','2026-08-22 10:03:43'),
(150052,30,'promo_logo','uploads/tenants/30/logo_mobile.png','STRING',NULL,1,'Paciente','2026-08-22 11:07:02'),
(150866,30,'agenda_horizonte','30','NUMBER',NULL,1,'Paciente','2026-08-22 11:10:50'),
(169742,30,'whatsapp_enabled','0','BOOLEAN','Habilita notificações automáticas via WhatsApp',1,'Paciente','2026-08-22 16:14:58'),
(169743,30,'whatsapp_api_url','','STRING','URL da Instância da API (Ex: Evolution API)',1,'Paciente','2026-08-22 16:14:58'),
(169744,30,'whatsapp_api_token','','STRING','Token de autenticação da API',1,'Paciente','2026-08-22 16:14:58'),
(169745,30,'ai_url','http://192.168.100.250:11434/api/generate','STRING','URL do motor de Inteligência Artificial (Ollama)',1,'Paciente','2026-08-22 16:14:58'),
(169746,30,'radar_enabled','0','BOOLEAN','Habilita o radar de faltas automáticas',1,'Paciente','2026-08-22 16:14:58'),
(169747,30,'radar_tolerance','15','NUMBER','Minutos de tolerância para falta automática',1,'Paciente','2026-08-22 16:14:58'),
(169748,30,'priority_mode','STRICT','STRING','Modo de chamada: STRICT (Sempre Prioridade) ou BALANCED (Intercalado)',1,'Paciente','2026-08-22 16:14:58'),
(169749,30,'priority_ratio','3','NUMBER','Quantidade de prioridades antes de um normal (no modo BALANCED)',1,'Paciente','2026-08-22 16:14:58'),
(169750,30,'feature_priority_selection','1','BOOLEAN','Habilita a tela de escolha entre Normal e Prioritário no Totem',1,'Paciente','2026-08-22 16:14:58'),
(169751,30,'empresa','Parada Obrigatória','STRING',NULL,1,'Paciente','2026-08-29 13:53:56'),
(169752,30,'logo_url','uploads/tenants/30/logo.png','STRING',NULL,1,'Paciente','2026-08-29 13:53:56'),
(169916,1,'whatsapp_enabled','0','BOOLEAN','Habilita notificações automáticas via WhatsApp',1,'Paciente','2026-08-30 10:35:19'),
(169917,1,'whatsapp_api_url','','STRING','URL da Instância da API (Ex: Evolution API)',1,'Paciente','2026-08-30 10:35:19'),
(169918,1,'whatsapp_api_token','','STRING','Token de autenticação da API',1,'Paciente','2026-08-30 10:35:19'),
(169919,1,'ai_url','http://192.168.100.250:11434/api/generate','STRING','URL do motor de Inteligência Artificial (Ollama)',1,'Paciente','2026-08-30 10:35:20'),
(169920,1,'radar_enabled','0','BOOLEAN','Habilita o radar de faltas automáticas',1,'Paciente','2026-08-30 10:35:20'),
(169921,1,'radar_tolerance','15','NUMBER','Minutos de tolerância para falta automática',1,'Paciente','2026-08-30 10:35:20'),
(169922,1,'priority_mode','STRICT','STRING','Modo de chamada: STRICT (Sempre Prioridade) ou BALANCED (Intercalado)',1,'Paciente','2026-08-30 10:35:20'),
(169923,1,'priority_ratio','3','NUMBER','Quantidade de prioridades antes de um normal (no modo BALANCED)',1,'Paciente','2026-08-30 10:35:20'),
(169924,1,'feature_priority_selection','1','BOOLEAN','Habilita a tela de escolha entre Normal e Prioritário no Totem',1,'Paciente','2026-08-30 10:35:20');
/*!40000 ALTER TABLE `configuracoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_config`
--

DROP TABLE IF EXISTS `fidelidade_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `meta_pontos` int(11) DEFAULT 10,
  `premio_desc` varchar(255) DEFAULT 'Corte Grátis',
  `ativo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id` (`tenant_id`),
  KEY `tenant_id_2` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_config`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_config` WRITE;
/*!40000 ALTER TABLE `fidelidade_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `fidelidade_config` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_historico`
--

DROP TABLE IF EXISTS `fidelidade_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_historico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `tipo` enum('CREDITO','DEBITO') NOT NULL,
  `pontos` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_historico`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_historico` WRITE;
/*!40000 ALTER TABLE `fidelidade_historico` DISABLE KEYS */;
/*!40000 ALTER TABLE `fidelidade_historico` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_saldo`
--

DROP TABLE IF EXISTS `fidelidade_saldo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_saldo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `saldo_pontos` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id` (`tenant_id`,`cliente_id`),
  KEY `tenant_id_2` (`tenant_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_saldo`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_saldo` WRITE;
/*!40000 ALTER TABLE `fidelidade_saldo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fidelidade_saldo` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `financeiro_acertos`
--

DROP TABLE IF EXISTS `financeiro_acertos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `financeiro_acertos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `data_pagamento` datetime DEFAULT current_timestamp(),
  `pago_por` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financeiro_acertos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `financeiro_acertos` WRITE;
/*!40000 ALTER TABLE `financeiro_acertos` DISABLE KEYS */;
/*!40000 ALTER TABLE `financeiro_acertos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `guiche_servicos`
--

DROP TABLE IF EXISTS `guiche_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guiche_servicos` (
  `guiche_id` int(11) NOT NULL,
  `servico_id` int(11) NOT NULL,
  PRIMARY KEY (`guiche_id`,`servico_id`),
  KEY `fk_gs_servico` (`servico_id`),
  CONSTRAINT `fk_gs_guiche` FOREIGN KEY (`guiche_id`) REFERENCES `guiches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gs_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guiche_servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `guiche_servicos` WRITE;
/*!40000 ALTER TABLE `guiche_servicos` DISABLE KEYS */;
INSERT INTO `guiche_servicos` VALUES
(1,1);
/*!40000 ALTER TABLE `guiche_servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `guiches`
--

DROP TABLE IF EXISTS `guiches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guiches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `icone` varchar(10) DEFAULT '⚙️',
  `cor` varchar(7) DEFAULT '#1565C0',
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_guiche_codigo` (`tenant_id`,`codigo`),
  CONSTRAINT `fk_guiches_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guiches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `guiches` WRITE;
/*!40000 ALTER TABLE `guiches` DISABLE KEYS */;
INSERT INTO `guiches` VALUES
(38,30,'01','Barber Ricardo','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 16:08:01'),
(39,30,'02','Barber João','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 16:07:44'),
(40,30,'03','Barber Piu','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 10:13:19');
/*!40000 ALTER TABLE `guiches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `licencas`
--

DROP TABLE IF EXISTS `licencas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `licencas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `chave` varchar(100) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  `uuid` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ATIVA',
  `validade` datetime DEFAULT NULL,
  `ultima_validacao` datetime DEFAULT NULL,
  `offline_dias` int(11) DEFAULT 15,
  `assinatura` text DEFAULT NULL,
  `hardware_id` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_licenca` (`tenant_id`,`chave`),
  CONSTRAINT `fk_licencas_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licencas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `licencas` WRITE;
/*!40000 ALTER TABLE `licencas` DISABLE KEYS */;
INSERT INTO `licencas` VALUES
(17,30,NULL,'FORCE-KEY-2026','1C3E5CE9B707A09D1A80A33D87C1BF30A5F7D05F68D10E628365A99A52AEF125','5579fd18-b48e-473e-a6e1-fb3cf1335700','ATIVA','2027-08-22 09:49:19',NULL,15,'64672622b4fe39f919a24217da7fa2aac74a576af16c21b221d9913d0122a271','174d0c49541eb26014b5f39f1286a04c9f63ba53b396de5b79d5a6522d81a234','2026-08-22 09:49:19');
/*!40000 ALTER TABLE `licencas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `arquivo` varchar(255) DEFAULT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `executado_em` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `arquivo` (`arquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operador_guiche`
--

DROP TABLE IF EXISTS `operador_guiche`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operador_guiche` (
  `operador_id` int(11) NOT NULL,
  `guiche_id` int(11) NOT NULL,
  PRIMARY KEY (`operador_id`,`guiche_id`),
  KEY `fk_og_guiche` (`guiche_id`),
  CONSTRAINT `fk_og_guiche` FOREIGN KEY (`guiche_id`) REFERENCES `guiches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_og_operador` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operador_guiche`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operador_guiche` WRITE;
/*!40000 ALTER TABLE `operador_guiche` DISABLE KEYS */;
/*!40000 ALTER TABLE `operador_guiche` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operador_servicos`
--

DROP TABLE IF EXISTS `operador_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operador_servicos` (
  `operador_id` int(11) NOT NULL,
  `servico_id` int(11) NOT NULL,
  PRIMARY KEY (`operador_id`,`servico_id`),
  KEY `fk_os_servico` (`servico_id`),
  CONSTRAINT `fk_os_operador` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_os_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operador_servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operador_servicos` WRITE;
/*!40000 ALTER TABLE `operador_servicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `operador_servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operadores`
--

DROP TABLE IF EXISTS `operadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nivel` enum('ADMIN','GERENTE','OPERADOR') DEFAULT 'OPERADOR',
  `guiche_id` int(11) DEFAULT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `prefixo` varchar(5) DEFAULT NULL,
  `foto_url` text DEFAULT NULL,
  `magic_token` varchar(100) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) DEFAULT 'ONLINE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_login` (`tenant_id`,`login`),
  CONSTRAINT `fk_operadores_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operadores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operadores` WRITE;
/*!40000 ALTER TABLE `operadores` DISABLE KEYS */;
INSERT INTO `operadores` VALUES
(30,30,'Administrador Master','admin','$2y$12$0yVHl1Nc7DCrbatIdRaUJ.xwOgPYZDcWSz8mXiS.k2f/rEZ/JMdhC','ADMIN',NULL,NULL,NULL,NULL,NULL,1,'2026-08-22 09:49:19','2026-08-22 09:49:19','ONLINE'),
(31,30,'Ricardo Brandão','ricardo','$2y$12$GFpEVZs12qxBJwqPnJ1l8eKYfssb2IZVaiwCUjgVp3TzUWix1M3US','OPERADOR',38,48,'RB','tenants/30/operador_31.png',NULL,1,'2026-08-22 10:03:43','2026-08-22 11:08:16','ONLINE'),
(33,30,'JOÃO','joao','$2y$12$I6xG/oV0PG6N.0X2kArd.OAVfbafdOA9DVmqp4k.nwfrqfsFbwZ82','OPERADOR',39,48,'JO','tenants/30/operador_33.png',NULL,1,'2026-08-22 11:08:54','2026-08-22 11:09:09','ONLINE'),
(34,30,'PIU','piu','$2y$12$6CRxMH2jKazkz0VxCwxqNOt9pFy9P5pZJ5LlhSY2mqCIjk0fxcXBS','OPERADOR',40,48,'PI','tenants/30/operador_34.png',NULL,1,'2026-08-22 11:09:35','2026-08-22 11:09:48','ONLINE');
/*!40000 ALTER TABLE `operadores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promocoes`
--

DROP TABLE IF EXISTS `promocoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` varchar(50) DEFAULT NULL,
  `imagem` text DEFAULT NULL,
  `ordem` int(11) DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_promocoes_tenant` (`tenant_id`),
  CONSTRAINT `fk_promocoes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promocoes` WRITE;
/*!40000 ALTER TABLE `promocoes` DISABLE KEYS */;
INSERT INTO `promocoes` VALUES
(6,30,'Cerveja Heineken Long Neck 330ml','20% OFF','R$ 19,90','CCA23C49.jpg',0,1,'2026-08-22 11:07:33','2026-08-22 11:07:33'),
(7,30,'Cerveja Budweiser, American Lager, Long Neck 330ml','','R$ 18,90','D71AC7C2.jpg',1,1,'2026-08-22 11:07:52','2026-08-22 11:07:52'),
(8,30,'Vitamina C 500mg 30 Comprimidos Neo Química','20% OFF','R$ 14 , 99','437319C3.webp',0,1,'2026-08-22 11:11:36','2026-08-22 11:11:36');
/*!40000 ALTER TABLE `promocoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `senhas`
--

DROP TABLE IF EXISTS `senhas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `senhas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `cliente_uuid` varchar(64) DEFAULT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `guiche_id` int(11) DEFAULT NULL,
  `operador_id` int(11) DEFAULT NULL,
  `device_id` varchar(100) DEFAULT NULL,
  `codigo` varchar(20) NOT NULL,
  `numero` int(11) NOT NULL,
  `prefixo` varchar(5) NOT NULL,
  `nome_cliente` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'AGUARDANDO',
  `tipo_atendimento` varchar(20) DEFAULT 'NORMAL',
  `data_agendamento` datetime DEFAULT NULL,
  `cancel_token` varchar(32) DEFAULT NULL,
  `pagamento_status` varchar(20) DEFAULT 'PENDENTE',
  `pagamento_id` varchar(100) DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT 0.00,
  `valor_total` decimal(10,2) DEFAULT 0.00,
  `servicos_desc` text DEFAULT NULL,
  `atendente` varchar(255) DEFAULT NULL,
  `atendente_nome` varchar(255) DEFAULT NULL,
  `emitida_em` datetime DEFAULT current_timestamp(),
  `chamada_em` datetime DEFAULT NULL,
  `finalizada_em` datetime DEFAULT NULL,
  `sincronizado` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cliente_id` int(11) DEFAULT 0,
  `pix_qr_code` text DEFAULT NULL,
  `pix_qr_base64` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `idx_tenant_status` (`tenant_id`,`status`),
  KEY `idx_tenant_created` (`tenant_id`,`created_at`),
  KEY `idx_senhas_status` (`status`),
  KEY `idx_senhas_uuid` (`uuid`),
  CONSTRAINT `fk_senhas_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senhas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `senhas` WRITE;
/*!40000 ALTER TABLE `senhas` DISABLE KEYS */;
INSERT INTO `senhas` VALUES
(84,30,'cfaabfbbb68207b0ae0e22afe87d6479','CLI-7ZL3R48BW',47,38,31,NULL,'AGD001',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','NORMAL','2026-08-22 12:00:00','0F50B31B','PAGO','STATIC_1787407948',0.00,70.00,'Degradê','Ricardo Brandão',NULL,'2026-08-22 12:00:00','2026-08-22 11:17:16','2026-08-22 11:24:12',0,'2026-08-22 11:12:28','2026-08-22 11:24:12',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',NULL),
(85,30,'23f3dc9d6cfe941c21f579a15bd2771e','24a6e14332b3376ae12fa64a06a63eda',47,39,33,'dev-1787079976163','JO001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787414723',0.00,70.00,'Degradê','JOÃO',NULL,'2026-08-22 13:05:23','2026-08-22 13:06:47','2026-08-22 13:08:10',0,'2026-08-22 13:05:23','2026-08-22 13:10:50',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(86,30,'0172951e6932aa2cabcf0163d3b568e5','CLI-JDKJB3E8F',49,39,33,NULL,'AGD003',0,'G','RICARDO','7191077018','FINALIZADA','NORMAL','2026-08-22 14:00:00','83D3F958','PENDENTE','STATIC_1787415142',0.00,35.00,'Corte Simples + Barba','JOÃO',NULL,'2026-08-22 14:00:00','2026-08-22 13:18:03','2026-08-22 13:39:32',0,'2026-08-22 13:12:22','2026-08-22 13:39:32',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',NULL);
/*!40000 ALTER TABLE `senhas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `servicos`
--

DROP TABLE IF EXISTS `servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `prefixo` varchar(5) NOT NULL,
  `icone` varchar(10) DEFAULT '?',
  `cor` varchar(7) DEFAULT '#1565C0',
  `ordem` int(11) DEFAULT 0,
  `tempo_medio` int(11) DEFAULT 10,
  `preco` decimal(10,2) DEFAULT 0.00,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_servico_slug` (`tenant_id`,`slug`),
  UNIQUE KEY `idx_tenant_servico_codigo` (`tenant_id`,`codigo`),
  CONSTRAINT `fk_servicos_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `servicos` WRITE;
/*!40000 ALTER TABLE `servicos` DISABLE KEYS */;
INSERT INTO `servicos` VALUES
(44,30,'1','Corte Simples','Máquina e Tesoura','CRS','✂️','#1565c0',1,10,30.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(45,30,'02','Vacinação','Vacinação','VAC','💉','#1565c0',2,10,0.00,0,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(46,30,'E','EXAMES','exames','EX','🩺','#c19c15',1,10,0.00,0,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(47,30,'2','Degradê','Taper Fade','DEG','👨🏼‍🦰','#010509',0,10,70.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(48,30,'1786887154869','Barba','barba','BAR','🧔🏾‍♂️','#1db4ff',0,30,15.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(49,30,'1786890923218','Corte Simples + Barba','corte-simples-+-barba','COR','✂️🧔🏾‍♂️','#1db4ff',0,45,35.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43');
/*!40000 ALTER TABLE `servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sync_queue`
--

DROP TABLE IF EXISTS `sync_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `evento` varchar(50) NOT NULL,
  `entidade` varchar(50) NOT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `prioridade` int(11) DEFAULT 0,
  `sincronizado` tinyint(1) DEFAULT 0,
  `tentativas` int(11) DEFAULT 0,
  `ultimo_erro` text DEFAULT NULL,
  `processado_em` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sync_tenant` (`tenant_id`),
  CONSTRAINT `fk_sync_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_queue`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sync_queue` WRITE;
/*!40000 ALTER TABLE `sync_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_queue` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_info`
--

DROP TABLE IF EXISTS `system_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `installation_uuid` varchar(100) NOT NULL,
  `empresa_uuid` varchar(100) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `versao` varchar(20) NOT NULL,
  `build` varchar(50) DEFAULT NULL,
  `ambiente` varchar(20) DEFAULT 'PRODUCAO',
  `created_at` datetime DEFAULT current_timestamp(),
  `last_sync` datetime DEFAULT NULL,
  `schema_version` int(11) DEFAULT 2,
  `php_version` varchar(50) DEFAULT NULL,
  `mariadb_version` varchar(50) DEFAULT NULL,
  `last_heartbeat` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sysinfo_tenant` (`tenant_id`),
  CONSTRAINT `fk_sysinfo_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_info`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_info` WRITE;
/*!40000 ALTER TABLE `system_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_info` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` enum('ATIVO','SUSPENSO','BLOQUEADO') DEFAULT 'ATIVO',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES
(1,'default-tenant-uuid','lite','Unidade Padrão','ATIVO','2026-08-29 13:53:55','2026-08-29 13:53:55'),
(30,'5579fd18-b48e-473e-a6e1-fb3cf1335700','paradaobrigatoriavilas','Parada Obrigatória','ATIVO','2026-08-22 09:49:19','2026-08-30 09:02:31');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'bt_enterprise_saas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-30 10:35:20
