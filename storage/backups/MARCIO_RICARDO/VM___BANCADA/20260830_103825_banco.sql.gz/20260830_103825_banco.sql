/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: bt_enterprise_saas
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `agenda_bloqueios`
--

DROP TABLE IF EXISTS `agenda_bloqueios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_bloqueios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_fim` time DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_bloqueios_tenant` (`tenant_id`),
  CONSTRAINT `fk_bloqueios_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_bloqueios`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_bloqueios` WRITE;
/*!40000 ALTER TABLE `agenda_bloqueios` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_bloqueios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agenda_regras`
--

DROP TABLE IF EXISTS `agenda_regras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_regras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `dia_semana` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `duracao_slot` int(11) DEFAULT 30,
  `liberacao_dia_semana` int(11) DEFAULT NULL,
  `liberacao_hora_inicio` time DEFAULT '00:00:00',
  `liberacao_hora_fim` time DEFAULT '23:59:59',
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_agenda_tenant` (`tenant_id`),
  KEY `fk_agenda_op` (`operador_id`),
  CONSTRAINT `fk_agenda_op` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agenda_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_regras`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_regras` WRITE;
/*!40000 ALTER TABLE `agenda_regras` DISABLE KEYS */;
INSERT INTO `agenda_regras` VALUES
(137,30,33,48,0,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(138,30,33,48,1,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(139,30,33,48,2,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(140,30,33,48,3,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(141,30,33,48,4,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(142,30,33,48,5,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(143,30,33,48,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-22 11:10:50','2026-08-22 11:10:50'),
(151,30,31,48,0,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(152,30,31,48,1,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(153,30,31,48,2,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(154,30,31,48,3,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(155,30,31,48,4,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(156,30,31,48,5,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(157,30,31,48,6,'08:00:00','23:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-24 21:53:32','2026-08-24 21:53:32'),
(188,35,42,68,0,'08:00:00','12:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(189,35,42,68,1,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(190,35,42,68,2,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(191,35,42,68,3,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',0,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(192,35,42,68,4,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(193,35,42,68,5,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(194,35,42,68,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:22:52','2026-08-26 19:22:52'),
(195,35,40,68,0,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',0,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(196,35,40,68,1,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(197,35,40,68,2,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(198,35,40,68,3,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(199,35,40,68,4,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(200,35,40,68,5,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(201,35,40,68,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:25:59','2026-08-26 19:25:59'),
(202,35,41,68,0,'08:00:00','12:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(203,35,41,68,1,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(204,35,41,68,2,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',0,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(205,35,41,68,3,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(206,35,41,68,4,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(207,35,41,68,5,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(208,35,41,68,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:27:34','2026-08-26 19:27:34'),
(209,35,43,68,0,'08:00:00','12:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(210,35,43,68,1,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',0,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(211,35,43,68,2,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(212,35,43,68,3,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(213,35,43,68,4,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(214,35,43,68,5,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(215,35,43,68,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-26 19:30:50','2026-08-26 19:30:50'),
(223,35,39,68,0,'08:00:00','11:30:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(224,35,39,68,1,'08:00:00','19:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(225,35,39,68,2,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(226,35,39,68,3,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(227,35,39,68,4,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(228,35,39,68,5,'08:00:00','20:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59'),
(229,35,39,68,6,'08:00:00','18:00:00',30,NULL,'00:00:00','23:59:00',1,'2026-08-29 15:40:59','2026-08-29 15:40:59');
/*!40000 ALTER TABLE `agenda_regras` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agenda_suspensoes`
--

DROP TABLE IF EXISTS `agenda_suspensoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agenda_suspensoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `identificador` varchar(100) NOT NULL,
  `motivo` text DEFAULT NULL,
  `data_fim` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_identificador` (`tenant_id`,`identificador`),
  CONSTRAINT `fk_suspensoes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda_suspensoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agenda_suspensoes` WRITE;
/*!40000 ALTER TABLE `agenda_suspensoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_suspensoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `atividades`
--

DROP TABLE IF EXISTS `atividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `atividades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `tipo` varchar(20) DEFAULT 'INFO',
  `nivel` varchar(20) DEFAULT 'INFO',
  `categoria` varchar(50) DEFAULT 'SYSTEM',
  `mensagem` text NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `data_criacao` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_atividades_tenant` (`tenant_id`),
  KEY `idx_atividades_data` (`data_criacao`),
  CONSTRAINT `fk_atividades_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividades`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `atividades` WRITE;
/*!40000 ALTER TABLE `atividades` DISABLE KEYS */;
INSERT INTO `atividades` VALUES
(1,30,'INFO','INFO','FILA','Senha AGD001 chamada para Babrber Ricardo','Ricardo Brandão',NULL,'2026-08-22 11:17:16'),
(2,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-22 13:05:23'),
(3,30,'INFO','INFO','FILA','Senha JO001 chamada para Babrber João','JOÃO',NULL,'2026-08-22 13:06:47'),
(4,30,'INFO','INFO','FILA','Senha AGD003 chamada para Babrber João','JOÃO',NULL,'2026-08-22 13:18:03'),
(5,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-22 18:41:23'),
(6,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-22 18:55:13'),
(7,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-22 19:43:43'),
(8,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Brandão',NULL,'2026-08-22 19:44:28'),
(9,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-22 19:50:26'),
(10,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-22 19:50:48'),
(11,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-22 23:12:56'),
(12,30,'INFO','INFO','FILA','Senha RB004 chamada para Barber Ricardo','Brandão',NULL,'2026-08-22 23:14:47'),
(13,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB005','Totem',NULL,'2026-08-22 23:43:25'),
(14,30,'INFO','INFO','FILA','Senha RB005 chamada para Guichê 1','Sistema',NULL,'2026-08-22 23:43:38'),
(15,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB006','Totem',NULL,'2026-08-22 23:56:26'),
(16,30,'INFO','INFO','FILA','Senha RB006 chamada para Guichê 1','Sistema',NULL,'2026-08-22 23:56:37'),
(17,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-23 00:01:33'),
(18,30,'INFO','INFO','FILA','Senha RB001 chamada para Guichê 1','Brandão',NULL,'2026-08-23 00:01:37'),
(19,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-23 00:14:42'),
(20,30,'INFO','INFO','FILA','Senha RB002 chamada para Guichê 1','Brandão',NULL,'2026-08-23 00:14:49'),
(21,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-23 10:53:01'),
(22,30,'INFO','INFO','FILA','Senha RB003 chamada para Guichê 1','Sistema',NULL,'2026-08-23 10:53:17'),
(23,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-23 11:13:10'),
(24,30,'INFO','INFO','FILA','Senha RB004 chamada para Guichê 1','Sistema',NULL,'2026-08-23 11:13:15'),
(25,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-23 11:56:25'),
(26,30,'INFO','INFO','FILA','Senha JO001 chamada para Guichê 1','Sistema',NULL,'2026-08-23 11:56:31'),
(27,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB005','Totem',NULL,'2026-08-23 18:05:03'),
(28,30,'INFO','INFO','FILA','Senha RB005 chamada para Barber Ricardo','Sistema',NULL,'2026-08-23 18:05:44'),
(29,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-24 12:58:01'),
(30,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 12:59:23'),
(31,30,'INFO','INFO','FILA','Senha AGD002 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 13:23:34'),
(32,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-24 13:44:43'),
(33,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 13:45:17'),
(34,30,'INFO','INFO','FILA','Senha AGD003 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 13:55:53'),
(35,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-24 20:32:51'),
(36,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 20:33:59'),
(37,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-24 21:24:20'),
(38,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB005','Totem',NULL,'2026-08-24 21:31:09'),
(39,30,'INFO','INFO','FILA','Senha RB004 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 21:44:43'),
(40,30,'INFO','INFO','FILA','Senha RB005 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 21:44:59'),
(41,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB006','Totem',NULL,'2026-08-24 21:54:41'),
(42,30,'INFO','INFO','FILA','Senha RB006 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 22:43:11'),
(43,30,'INFO','INFO','FILA','Senha AGD011 chamada para Barber Ricardo','Sistema',NULL,'2026-08-24 22:45:08'),
(44,30,'INFO','INFO','FILA','Senha AGD009 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 10:08:31'),
(45,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-25 11:47:01'),
(46,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-25 11:47:13'),
(47,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-25 14:15:18'),
(48,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 14:54:13'),
(49,30,'INFO','INFO','FILA','Senha AGD003 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 14:54:28'),
(50,30,'SUCCESS','INFO','FILA','Nova senha emitida: BAR001','Totem',NULL,'2026-08-25 17:41:54'),
(51,30,'SUCCESS','INFO','FILA','Nova senha emitida: BAR002','Totem',NULL,'2026-08-25 17:45:24'),
(52,30,'INFO','INFO','FILA','Senha BAR001 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 17:46:18'),
(53,30,'INFO','INFO','FILA','Senha BAR002 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 17:46:27'),
(54,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-25 21:24:28'),
(55,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-25 21:28:05'),
(56,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB005','Totem',NULL,'2026-08-25 21:29:08'),
(57,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB006','Totem',NULL,'2026-08-25 21:29:35'),
(58,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 21:30:18'),
(59,30,'INFO','INFO','FILA','Senha RB004 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 21:30:35'),
(60,30,'INFO','INFO','FILA','Senha RB005 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 21:30:46'),
(61,30,'INFO','INFO','FILA','Senha RB006 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 21:31:02'),
(62,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-25 21:36:38'),
(63,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB007','Totem',NULL,'2026-08-25 21:46:10'),
(64,30,'INFO','INFO','FILA','Senha RB007 chamada para Barber Ricardo','Sistema',NULL,'2026-08-25 22:00:04'),
(65,30,'SUCCESS','INFO','FILA','Nova senha emitida: BAR001','Totem',NULL,'2026-08-25 22:05:28'),
(66,30,'INFO','INFO','FILA','Senha JO001 chamada para Barber João','Joâo',NULL,'2026-08-25 22:24:58'),
(67,30,'INFO','INFO','FILA','Senha BAR001 chamada para Barber João','Joâo',NULL,'2026-08-25 22:25:16'),
(68,30,'SUCCESS','INFO','FILA','Nova senha emitida: DEG001','Totem',NULL,'2026-08-25 22:35:42'),
(69,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI001','Totem',NULL,'2026-08-25 22:54:25'),
(70,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI002','Totem',NULL,'2026-08-25 22:58:05'),
(71,30,'INFO','INFO','FILA','Senha DEG001 chamada para Barber Piu','Piu',NULL,'2026-08-25 22:59:22'),
(72,30,'INFO','INFO','FILA','Senha PI001 chamada para Barber Piu','Piu',NULL,'2026-08-25 22:59:44'),
(73,30,'INFO','INFO','FILA','Senha PI002 chamada para Barber Piu','Piu',NULL,'2026-08-25 22:59:54'),
(74,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB008','Totem',NULL,'2026-08-25 23:08:41'),
(75,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB009','Totem',NULL,'2026-08-25 23:15:48'),
(76,30,'INFO','INFO','FILA','Senha RB008 chamada para Barber Ricardo','Brandão',NULL,'2026-08-25 23:28:53'),
(77,30,'INFO','INFO','FILA','Senha RB009 chamada para Barber Ricardo','Brandão',NULL,'2026-08-25 23:29:07'),
(78,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB010','Totem',NULL,'2026-08-25 23:43:46'),
(79,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-26 08:25:33'),
(80,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Sistema',NULL,'2026-08-26 08:25:59'),
(81,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-26 08:42:54'),
(82,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Sistema',NULL,'2026-08-26 08:47:07'),
(83,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-26 10:51:47'),
(84,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-26 10:55:19'),
(85,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-26 10:58:25'),
(86,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-26 10:58:31'),
(87,30,'INFO','INFO','FILA','Senha RB004 chamada para Barber Ricardo','Brandão',NULL,'2026-08-26 11:06:31'),
(88,30,'INFO','INFO','FILA','Senha JO001 chamada para Barber João','Joâo',NULL,'2026-08-26 11:14:59'),
(89,35,'INFO','INFO','FILA','Senha AGD001 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-26 18:24:43'),
(90,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS001','Totem',NULL,'2026-08-26 18:43:53'),
(91,35,'INFO','INFO','FILA','Senha IS001 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-26 18:44:55'),
(92,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS001','Totem',NULL,'2026-08-27 14:20:06'),
(93,35,'INFO','INFO','FILA','Senha IS001 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-27 14:22:02'),
(94,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-27 21:12:15'),
(95,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Ricardo',NULL,'2026-08-27 21:33:28'),
(96,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-28 08:01:24'),
(97,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 08:11:24'),
(98,30,'INFO','INFO','FILA','Senha AGD001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 08:13:03'),
(99,30,'INFO','INFO','FILA','Senha AGD003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 08:50:24'),
(100,30,'INFO','INFO','FILA','Senha AGD004 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 08:57:38'),
(101,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-28 09:19:00'),
(102,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 09:21:46'),
(103,30,'INFO','INFO','FILA','Senha AGD005 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 09:21:58'),
(104,30,'INFO','INFO','FILA','Senha AGD007 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 09:31:21'),
(105,30,'INFO','INFO','FILA','Senha AGD008 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 09:38:18'),
(106,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-28 09:43:20'),
(107,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-28 09:50:11'),
(108,35,'SUCCESS','INFO','FILA','Nova senha emitida: YS001','Totem',NULL,'2026-08-28 15:25:10'),
(109,35,'INFO','INFO','FILA','Senha YS001 chamada para BARBEIRO YSMAEL','YSMAEL',NULL,'2026-08-28 15:25:20'),
(110,35,'SUCCESS','INFO','FILA','Nova senha emitida: YS002','Totem',NULL,'2026-08-28 15:27:18'),
(111,30,'INFO','INFO','FILA','Senha AGD010 chamada para Barber Ricardo','Sistema',NULL,'2026-08-28 18:03:50'),
(112,30,'INFO','INFO','FILA','Senha AGD011 chamada para Barber Ricardo','Sistema',NULL,'2026-08-28 18:06:29'),
(113,30,'INFO','INFO','FILA','Senha AGD012 chamada para Barber Ricardo','Sistema',NULL,'2026-08-28 18:22:10'),
(114,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO001','Totem',NULL,'2026-08-29 00:01:24'),
(115,30,'INFO','INFO','FILA','Senha JO001 chamada para Barber João','Joâo',NULL,'2026-08-29 00:12:55'),
(116,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-29 08:09:38'),
(117,30,'INFO','INFO','FILA','Senha AGD013 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 08:15:47'),
(118,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 08:16:36'),
(119,30,'SUCCESS','INFO','FILA','Nova senha emitida: JO002','Totem',NULL,'2026-08-29 08:20:12'),
(120,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-29 08:20:50'),
(121,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 08:22:02'),
(122,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI001','Totem',NULL,'2026-08-29 08:42:46'),
(123,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-29 08:43:06'),
(124,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 08:43:12'),
(125,30,'INFO','INFO','FILA','Senha JO002 chamada para Barber João','Joâo',NULL,'2026-08-29 08:44:03'),
(126,30,'INFO','INFO','FILA','Senha PI001 chamada para Barber Piu','Piu',NULL,'2026-08-29 08:48:21'),
(127,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI002','Totem',NULL,'2026-08-29 09:01:02'),
(128,30,'INFO','INFO','FILA','Senha PI002 chamada para Barber Piu','Piu',NULL,'2026-08-29 09:01:06'),
(129,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI003','Totem',NULL,'2026-08-29 09:23:10'),
(130,30,'INFO','INFO','FILA','Senha PI003 chamada para Barber Piu','Piu',NULL,'2026-08-29 09:34:03'),
(131,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI004','Totem',NULL,'2026-08-29 10:38:30'),
(132,30,'INFO','INFO','FILA','Senha PI004 chamada para Barber Piu','Piu',NULL,'2026-08-29 10:43:07'),
(133,30,'SUCCESS','INFO','FILA','Nova senha emitida: PI005','Totem',NULL,'2026-08-29 10:44:21'),
(134,30,'INFO','INFO','FILA','Senha PI005 chamada para Barber Piu','Piu',NULL,'2026-08-29 10:44:29'),
(135,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS001','Totem',NULL,'2026-08-29 13:57:09'),
(136,35,'INFO','INFO','FILA','Senha AGD001 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 14:05:46'),
(137,35,'INFO','INFO','FILA','Senha IS001 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 14:08:36'),
(138,35,'INFO','INFO','FILA','Senha AGD002 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 14:26:33'),
(139,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS002','Totem',NULL,'2026-08-29 14:33:31'),
(140,35,'INFO','INFO','FILA','Senha IS002 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 14:33:50'),
(141,35,'INFO','INFO','FILA','Senha AGD003 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 14:36:16'),
(142,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS003','Totem',NULL,'2026-08-29 15:26:23'),
(143,35,'INFO','INFO','FILA','Senha IS003 chamada para BARBEIRO ISRAEL','Sistema',NULL,'2026-08-29 15:29:06'),
(144,35,'INFO','INFO','FILA','Senha AGD006 chamada para BARBEIRO ISRAEL','Sistema',NULL,'2026-08-29 15:29:59'),
(145,35,'SUCCESS','INFO','FILA','Nova senha emitida: YS001','Totem',NULL,'2026-08-29 15:34:17'),
(146,35,'INFO','INFO','FILA','Senha YS001 chamada para BARBEIRO YSMAEL','Sistema',NULL,'2026-08-29 15:34:24'),
(147,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS004','Totem',NULL,'2026-08-29 15:44:41'),
(148,35,'INFO','INFO','FILA','Senha IS004 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 15:46:46'),
(149,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS005','Totem',NULL,'2026-08-29 15:51:08'),
(150,35,'INFO','INFO','FILA','Senha IS005 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 15:51:34'),
(151,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS006','Totem',NULL,'2026-08-29 15:53:21'),
(152,35,'INFO','INFO','FILA','Senha IS006 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 15:56:46'),
(153,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS007','Totem',NULL,'2026-08-29 16:53:53'),
(154,35,'INFO','INFO','FILA','Senha IS007 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 16:54:03'),
(155,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS008','Totem',NULL,'2026-08-29 20:48:04'),
(156,35,'INFO','INFO','FILA','Senha IS008 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 20:49:48'),
(157,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS009','Totem',NULL,'2026-08-29 21:19:23'),
(158,35,'INFO','INFO','FILA','Senha IS009 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 21:20:14'),
(159,35,'SUCCESS','INFO','FILA','Nova senha emitida: IS010','Totem',NULL,'2026-08-29 21:21:07'),
(160,35,'INFO','INFO','FILA','Senha IS010 chamada para BARBEIRO ISRAEL','ISRAEL',NULL,'2026-08-29 21:21:39'),
(161,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB004','Totem',NULL,'2026-08-29 21:53:22'),
(162,30,'INFO','INFO','FILA','Senha RB004 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 21:54:15'),
(163,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB005','Totem',NULL,'2026-08-29 21:57:50'),
(164,30,'INFO','INFO','FILA','Senha RB005 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 21:58:31'),
(165,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB006','Totem',NULL,'2026-08-29 22:03:54'),
(166,30,'INFO','INFO','FILA','Senha RB006 chamada para Barber Ricardo','Brandão',NULL,'2026-08-29 22:04:23'),
(167,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB001','Totem',NULL,'2026-08-30 09:15:09'),
(168,30,'INFO','INFO','FILA','Senha RB001 chamada para Barber Ricardo','Brandão',NULL,'2026-08-30 09:16:25'),
(169,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB002','Totem',NULL,'2026-08-30 10:09:48'),
(170,30,'SUCCESS','INFO','FILA','Nova senha emitida: RB003','Totem',NULL,'2026-08-30 10:10:40'),
(171,30,'INFO','INFO','FILA','Senha RB002 chamada para Barber Ricardo','Brandão',NULL,'2026-08-30 10:12:54'),
(172,30,'INFO','INFO','FILA','Senha RB003 chamada para Barber Ricardo','Brandão',NULL,'2026-08-30 10:13:31');
/*!40000 ALTER TABLE `atividades` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `evento` varchar(100) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `detalhes` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_auditoria_tenant` (`tenant_id`),
  CONSTRAINT `fk_auditoria_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `uuid` varchar(100) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `documento` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ATIVO',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `fk_clientes_tenant` (`tenant_id`),
  CONSTRAINT `fk_clientes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES
(16,30,'caf0712c606d33a143da2ea8e2c1ca02','MARCIO RICARDO BRANDãO DE JESUS',NULL,'2026-08-22 19:53:08','71991077018','fciazerohoraddns@gmail.com','2026-08-22','ATIVO','2026-08-29 21:56:50'),
(17,30,'b7b548094d74a2f7a8b6b203427cd5db','CLAUDIONOR SANTANA DOS SANTOS',NULL,'2026-08-24 12:57:16','71984850615','','2026-08-01','ATIVO','2026-08-24 12:57:16'),
(18,30,'4cd5d8d481a34e7ae7ac6422af34071b','ITA PALOMA',NULL,'2026-08-24 21:30:50','71991007491','','2026-08-24','ATIVO','2026-08-24 21:30:50'),
(19,30,'22c269b7c1471e65fd4ac1a7f09dc00b','RICARDO  BRANDãO',NULL,'2026-08-25 13:33:03','71988394069','','2026-08-25','ATIVO','2026-08-25 13:33:03'),
(29,35,'cca7b8cd1e33004e7d62a11021e76cce','VICTOR HUGO CARVALHO NOGUEIRA DOS SANTOS',NULL,'2026-08-26 16:37:02','71983600449','','2011-07-05','ATIVO','2026-08-26 16:37:02'),
(30,35,'83e3343e6eaba23e1564c9e4c054476f','MARCIO RICARDO BRANDãO DE JESUS',NULL,'2026-08-27 21:25:52','71991077018','',NULL,'ATIVO','2026-08-27 21:25:52'),
(31,35,'5efd68f69239637a25bfa5f4778af955','ISRAEL SILVA',NULL,'2026-08-29 13:14:09','71991050259','','1989-09-19','ATIVO','2026-08-29 13:14:09'),
(32,35,'3c27f9204be6adc91e521e93050892e5','DANILO VIEIRA DOS ANJOS',NULL,'2026-08-29 15:40:42','71991237721','','1983-05-18','ATIVO','2026-08-29 15:40:42'),
(33,35,'e1cc7afb602f14367333eb6793681e0f','DEVIDE CANDEIAS',NULL,'2026-08-29 16:59:40','71997182482','','1997-04-14','ATIVO','2026-08-29 16:59:40'),
(34,35,'f0f6df669b117de652dd3f71beeb3b7c','JORDAN MIRANDA',NULL,'2026-08-29 18:13:03','71987835034','','1987-11-05','ATIVO','2026-08-29 18:13:03');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clube_assinaturas`
--

DROP TABLE IF EXISTS `clube_assinaturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clube_assinaturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `plano_id` int(11) NOT NULL,
  `cortes_restantes` int(11) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `status` enum('ATIVA','EXPIRADA','CANCELADA') DEFAULT 'ATIVA',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `tenant_id` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clube_assinaturas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clube_assinaturas` WRITE;
/*!40000 ALTER TABLE `clube_assinaturas` DISABLE KEYS */;
INSERT INTO `clube_assinaturas` VALUES
(1,30,16,3,0,'2026-08-24','2026-09-23','ATIVA','2026-08-24 22:34:58'),
(2,30,15,3,4,'2026-08-24','2026-09-23','ATIVA','2026-08-24 22:38:04'),
(3,30,18,2,4,'2026-08-24','2026-09-23','ATIVA','2026-08-24 22:38:10'),
(4,30,18,2,4,'2026-08-24','2026-09-23','ATIVA','2026-08-24 22:41:16'),
(5,35,30,6,4,'2026-08-27','2026-09-26','ATIVA','2026-08-27 23:48:49'),
(6,35,33,8,2,'2026-08-29','2026-09-28','ATIVA','2026-08-29 17:00:09'),
(7,30,16,3,4,'2026-08-29','2026-09-28','ATIVA','2026-08-29 21:56:59');
/*!40000 ALTER TABLE `clube_assinaturas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clube_planos`
--

DROP TABLE IF EXISTS `clube_planos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clube_planos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `qtd_cortes` int(11) DEFAULT 4,
  `validade_dias` int(11) DEFAULT 30,
  `descricao` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `servico_vinculado_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clube_planos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clube_planos` WRITE;
/*!40000 ALTER TABLE `clube_planos` DISABLE KEYS */;
INSERT INTO `clube_planos` VALUES
(1,30,'4 cortes',0.00,4,30,NULL,0,'2026-08-24 22:29:35',NULL),
(2,30,'Teste',100.00,4,30,NULL,0,'2026-08-24 22:29:46',NULL),
(3,30,'4 cortes',150.00,4,30,NULL,1,'2026-08-24 22:30:04',44),
(4,30,'BEM-VINDO',0.00,0,0,'10% OFF no seu primeiro atendimento',0,'2026-08-25 12:46:32',NULL),
(5,35,'PACOTE MENSAL (CABELO)',120.00,4,30,NULL,0,'2026-08-26 16:25:51',NULL),
(6,35,'PACOTE MENSAL (CABELO 4 CORTES)',120.00,4,30,NULL,1,'2026-08-26 16:29:04',NULL),
(7,35,'4 CORTES',120.00,4,30,NULL,0,'2026-08-29 15:56:50',NULL),
(8,35,'PACOTE MENSAL (CABELO 2 CORTES)',70.00,2,30,NULL,1,'2026-08-29 15:58:23',NULL),
(9,35,'PACOTE MENSAL (CABELO 3 CORTES)',100.00,3,30,NULL,1,'2026-08-29 15:58:51',NULL),
(10,35,'PACOTE MENSAL ( 4 BARBAS )',100.00,4,30,NULL,1,'2026-08-29 16:00:09',NULL),
(11,35,'PACOTE MENSAL ( 3 BARBAS )',80.00,3,30,NULL,1,'2026-08-29 16:01:49',NULL),
(12,35,'PACOTE MENSAL ( 2 BARBAS )',60.00,2,30,NULL,1,'2026-08-29 16:02:52',NULL);
/*!40000 ALTER TABLE `clube_planos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `configuracoes`
--

DROP TABLE IF EXISTS `configuracoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `chave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `tipo` varchar(20) DEFAULT 'STRING',
  `descricao` text DEFAULT NULL,
  `editavel` tinyint(1) DEFAULT 1,
  `label_cliente` varchar(50) DEFAULT 'Paciente',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_chave` (`tenant_id`,`chave`),
  CONSTRAINT `fk_config_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=830396 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `configuracoes` WRITE;
/*!40000 ALTER TABLE `configuracoes` DISABLE KEYS */;
INSERT INTO `configuracoes` VALUES
(140620,30,'master_url','http://api.brandaotech.com.br/api/v1/sync.php','STRING',NULL,1,'Paciente','2026-08-26 10:10:36'),
(140621,30,'uuid','5579fd18-b48e-473e-a6e1-fb3cf1335700','STRING',NULL,1,'Paciente','2026-08-22 09:49:19'),
(140622,30,'token','1C3E5CE9B707A09D1A80A33D87C1BF30A5F7D05F68D10E628365A99A52AEF125','STRING',NULL,1,'Paciente','2026-08-22 09:49:19'),
(145843,30,'app_name','BT Queue Enterprise','STRING','Nome da aplicação local',1,'Paciente','2026-08-22 10:03:43'),
(145844,30,'offline_limit_days','7','INT','Dias permitidos de operação sem sincronização',1,'Paciente','2026-08-22 10:03:43'),
(145845,30,'printer_name','BT_TICKET','STRING','Nome da impressora compartilhada no Windows',1,'Paciente','2026-08-22 10:03:43'),
(145846,30,'integration_token','CEF3504AC887599D03C07639D5C90D63','STRING','Token de Segurança para Chamadas via API Externa',1,'Paciente','2026-08-22 10:03:43'),
(145847,30,'qr_security_salt','bf3f736fa4c0024aca6a87317277fd93','STRING','Chave secreta para validação de QR Code dinâmico',1,'Paciente','2026-08-22 10:03:43'),
(145851,30,'feature_max_devices','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145852,30,'feature_voice_enabled','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145853,30,'feature_custom_branding','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145854,30,'feature_reports','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145855,30,'feature_multi_ticket','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(145856,30,'feature_hybrid_scheduling','1','BOOLEAN',NULL,1,'Paciente','2026-08-22 10:03:43'),
(262583,30,'agenda_horizonte','30','NUMBER',NULL,1,'Paciente','2026-08-24 21:53:32'),
(267653,30,'modo','cloud','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267654,30,'url_local','http://192.168.100.245','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267655,30,'url_publica','http://lite.brandaotech.com.br','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267658,30,'slogan','','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267659,30,'local_print_ip','192.168.100.126','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267661,30,'opening_time','00:00','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(267662,30,'closing_time','23:59','STRING',NULL,1,'Paciente','2026-08-24 22:49:25'),
(314545,30,'label_cliente','Cliente','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(314552,30,'payment_strategy','mercadopago','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(314553,30,'booking_release_mode','immediate','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(314554,30,'mercadopago_token','','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(314555,30,'pix_chave_estatica','71991077018','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(314556,30,'mercadopago_test_mode','0','STRING',NULL,1,'Paciente','2026-08-25 20:12:43'),
(353843,30,'promo_campanha','','STRING',NULL,1,'Paciente','2026-08-26 08:42:46'),
(376071,35,'uuid','4aa0051b-2af1-44a4-a361-ea063c1aaf02','STRING',NULL,1,'Paciente','2026-08-26 11:15:11'),
(376072,35,'token','3F6AF87BA87ECEBD4A8397D7FBD2C4ADCB814C2AA37700411FF5F223A5A2DFE2','STRING',NULL,1,'Paciente','2026-08-26 11:15:11'),
(376073,35,'master_url','http://api.brandaotech.com.br/api/v1/sync.php','STRING',NULL,1,'Paciente','2026-08-26 11:15:11'),
(378567,35,'logo_url','uploads/tenants/35/logo.png','STRING',NULL,1,'Paciente','2026-08-26 11:22:28'),
(409046,35,'modo','cloud','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409047,35,'url_local','','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409048,35,'url_publica','https://paradaobrigatoriavilas.brandaotech.com.br/','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409051,35,'slogan','','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409052,35,'local_print_ip','','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409054,35,'opening_time','00:00','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(409055,35,'closing_time','23:59','STRING',NULL,1,'Paciente','2026-08-26 17:38:52'),
(423837,30,'empresa','VM - BANCADA','STRING',NULL,1,'Paciente','2026-08-26 19:07:24'),
(423838,30,'whatsapp','','STRING',NULL,1,'Paciente','2026-08-26 19:07:24'),
(423839,30,'instagram','','STRING',NULL,1,'Paciente','2026-08-26 19:07:24'),
(423903,30,'logo_url','uploads/tenants/30/logo.png','STRING',NULL,1,'Paciente','2026-08-26 19:07:26'),
(509325,35,'whatsapp','71 9211-0063','STRING',NULL,1,'Paciente','2026-08-28 20:33:06'),
(509326,35,'instagram','','STRING',NULL,1,'Paciente','2026-08-28 20:33:06'),
(510623,30,'promo_logo','uploads/tenants/30/logo_mobile.png','STRING',NULL,1,'Paciente','2026-08-28 21:09:34'),
(649946,35,'promo_logo','uploads/tenants/35/logo_mobile.png','STRING',NULL,1,'Paciente','2026-08-29 13:54:57'),
(690452,35,'agenda_horizonte','30','NUMBER',NULL,1,'Paciente','2026-08-29 15:40:59'),
(702209,35,'empresa','Parada Obrigatória Vilas','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702210,35,'label_cliente','cliente','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702217,35,'payment_strategy','disabled','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702218,35,'booking_release_mode','immediate','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702219,35,'mercadopago_token','','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702220,35,'pix_chave_estatica','','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(702221,35,'mercadopago_test_mode','0','STRING',NULL,1,'Paciente','2026-08-29 16:08:47'),
(830252,30,'whatsapp_enabled','0','BOOLEAN','Habilita notificações automáticas via WhatsApp',1,'Paciente','2026-08-30 10:37:43'),
(830253,30,'whatsapp_api_url','','STRING','URL da Instância da API (Ex: Evolution API)',1,'Paciente','2026-08-30 10:37:43'),
(830254,30,'whatsapp_api_token','','STRING','Token de autenticação da API',1,'Paciente','2026-08-30 10:37:43'),
(830255,30,'ai_url','http://192.168.100.250:11434/api/generate','STRING','URL do motor de Inteligência Artificial (Ollama)',1,'Paciente','2026-08-30 10:37:43'),
(830256,30,'radar_enabled','0','BOOLEAN','Habilita o radar de faltas automáticas',1,'Paciente','2026-08-30 10:37:43'),
(830257,30,'radar_tolerance','15','NUMBER','Minutos de tolerância para falta automática',1,'Paciente','2026-08-30 10:37:43'),
(830258,30,'priority_mode','STRICT','STRING','Modo de chamada: STRICT (Sempre Prioridade) ou BALANCED (Intercalado)',1,'Paciente','2026-08-30 10:37:43'),
(830259,30,'priority_ratio','3','NUMBER','Quantidade de prioridades antes de um normal (no modo BALANCED)',1,'Paciente','2026-08-30 10:37:43'),
(830260,30,'feature_priority_selection','1','BOOLEAN','Habilita a tela de escolha entre Normal e Prioritário no Totem',1,'Paciente','2026-08-30 10:37:43'),
(830387,35,'whatsapp_enabled','0','BOOLEAN','Habilita notificações automáticas via WhatsApp',1,'Paciente','2026-08-30 10:38:25'),
(830388,35,'whatsapp_api_url','','STRING','URL da Instância da API (Ex: Evolution API)',1,'Paciente','2026-08-30 10:38:25'),
(830389,35,'whatsapp_api_token','','STRING','Token de autenticação da API',1,'Paciente','2026-08-30 10:38:25'),
(830390,35,'ai_url','http://192.168.100.250:11434/api/generate','STRING','URL do motor de Inteligência Artificial (Ollama)',1,'Paciente','2026-08-30 10:38:25'),
(830391,35,'radar_enabled','0','BOOLEAN','Habilita o radar de faltas automáticas',1,'Paciente','2026-08-30 10:38:25'),
(830392,35,'radar_tolerance','15','NUMBER','Minutos de tolerância para falta automática',1,'Paciente','2026-08-30 10:38:25'),
(830393,35,'priority_mode','STRICT','STRING','Modo de chamada: STRICT (Sempre Prioridade) ou BALANCED (Intercalado)',1,'Paciente','2026-08-30 10:38:25'),
(830394,35,'priority_ratio','3','NUMBER','Quantidade de prioridades antes de um normal (no modo BALANCED)',1,'Paciente','2026-08-30 10:38:25'),
(830395,35,'feature_priority_selection','1','BOOLEAN','Habilita a tela de escolha entre Normal e Prioritário no Totem',1,'Paciente','2026-08-30 10:38:25');
/*!40000 ALTER TABLE `configuracoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_config`
--

DROP TABLE IF EXISTS `fidelidade_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `meta_pontos` int(11) DEFAULT 10,
  `premio_desc` varchar(255) DEFAULT 'Corte Grátis',
  `ativo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id` (`tenant_id`),
  KEY `tenant_id_2` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_config`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_config` WRITE;
/*!40000 ALTER TABLE `fidelidade_config` DISABLE KEYS */;
INSERT INTO `fidelidade_config` VALUES
(1,1,10,'Corte Grátis',1),
(6,35,10,'Corte Grátis',0),
(8,30,10,'20% OFF',1);
/*!40000 ALTER TABLE `fidelidade_config` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_historico`
--

DROP TABLE IF EXISTS `fidelidade_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_historico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `tipo` enum('CREDITO','DEBITO') NOT NULL,
  `pontos` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_historico`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_historico` WRITE;
/*!40000 ALTER TABLE `fidelidade_historico` DISABLE KEYS */;
INSERT INTO `fidelidade_historico` VALUES
(1,1,1,'CREDITO',1,'Crédito manual via painel',0,'2026-08-20 18:18:33'),
(2,30,15,'CREDITO',1,'Corte: Corte Simples + Barba',89,'2026-08-22 19:51:01'),
(3,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',90,'2026-08-22 23:15:34'),
(4,30,17,'CREDITO',1,'Corte: Barba + Corte Simples + Barba',99,'2026-08-24 12:59:54'),
(5,30,17,'CREDITO',1,'Corte: Degradê + Corte Simples + Barba',100,'2026-08-24 13:36:09'),
(6,30,15,'CREDITO',1,'Corte: Degradê',103,'2026-08-24 20:34:28'),
(7,30,16,'CREDITO',1,'Corte: Escova',104,'2026-08-24 21:44:51'),
(8,30,18,'CREDITO',1,'Corte: Degradê',105,'2026-08-24 22:41:57'),
(9,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:51:47'),
(10,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:51:51'),
(11,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:51:59'),
(12,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:52:06'),
(13,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:52:09'),
(14,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:52:12'),
(15,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:52:14'),
(16,30,16,'CREDITO',1,'Crédito manual via painel',0,'2026-08-24 22:52:25'),
(17,30,16,'CREDITO',1,'Corte: Escova',109,'2026-08-25 09:11:13'),
(18,30,16,'CREDITO',1,'Corte: Escova',108,'2026-08-25 09:11:15'),
(19,30,18,'CREDITO',1,'Corte: Corte Simples + Barba',107,'2026-08-25 10:09:00'),
(20,30,16,'CREDITO',1,'Corte: Escova',110,'2026-08-25 11:47:18'),
(21,30,16,'CREDITO',1,'Corte: Corte Simples (VIP)',112,'2026-08-25 14:54:37'),
(22,30,16,'CREDITO',1,'Corte: Barba',113,'2026-08-25 17:46:23'),
(23,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',115,'2026-08-25 21:30:25'),
(24,30,16,'CREDITO',1,'Corte: Degradê',116,'2026-08-25 21:30:39'),
(25,30,16,'CREDITO',1,'Corte: Barba',120,'2026-08-25 22:00:19'),
(26,30,16,'CREDITO',1,'Corte: Barba',120,'2026-08-25 22:00:21'),
(27,30,16,'CREDITO',1,'Corte: Degradê',119,'2026-08-25 22:25:09'),
(28,30,16,'CREDITO',1,'Corte: Barba',121,'2026-08-25 22:25:33'),
(29,30,16,'CREDITO',1,'Corte: Degradê',122,'2026-08-25 22:59:31'),
(30,30,16,'CREDITO',1,'Corte: Corte Simples',123,'2026-08-25 22:59:47'),
(31,30,16,'CREDITO',1,'Corte: Barba',124,'2026-08-25 22:59:59'),
(32,30,16,'CREDITO',1,'Corte: Barba',125,'2026-08-25 23:28:59'),
(33,30,16,'CREDITO',1,'Corte: Escova',126,'2026-08-25 23:29:16'),
(34,30,16,'CREDITO',1,'Corte: Degradê',128,'2026-08-26 08:27:08'),
(35,30,16,'CREDITO',1,'Corte: Degradê',129,'2026-08-26 08:47:10'),
(36,30,16,'CREDITO',1,'Corte: Degradê',130,'2026-08-26 10:55:26'),
(37,30,16,'CREDITO',1,'Corte: Escova',131,'2026-08-26 11:06:55'),
(38,30,16,'CREDITO',1,'Corte: Degradê',132,'2026-08-26 11:15:05'),
(39,30,16,'CREDITO',1,'Corte: Degradê',127,'2026-08-26 19:03:33'),
(40,30,16,'CREDITO',1,'Corte: Corte Simples',141,'2026-08-28 08:12:56'),
(41,30,16,'CREDITO',1,'Corte: Corte Simples (VIP)',140,'2026-08-28 08:14:20'),
(42,30,16,'CREDITO',1,'Corte: Corte Simples (VIP)',142,'2026-08-28 08:51:14'),
(43,30,16,'CREDITO',1,'Corte: Corte Simples (VIP)',143,'2026-08-28 09:05:05'),
(44,30,16,'CREDITO',1,'Corte: Corte Simples',145,'2026-08-28 09:21:51'),
(45,30,16,'CREDITO',1,'Corte: Corte Simples',144,'2026-08-28 09:22:06'),
(46,30,16,'CREDITO',1,'Corte: Escova',146,'2026-08-28 09:23:16'),
(47,30,16,'CREDITO',1,'Corte: Barba',147,'2026-08-28 09:32:53'),
(48,30,19,'CREDITO',1,'Corte: Corte Simples + Barba',151,'2026-08-28 17:56:15'),
(49,30,19,'CREDITO',1,'Corte: Degradê',152,'2026-08-28 18:07:00'),
(50,30,19,'CREDITO',1,'Corte: Escova',153,'2026-08-28 18:23:39'),
(51,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',155,'2026-08-29 08:11:44'),
(52,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',154,'2026-08-29 08:16:25'),
(53,30,16,'CREDITO',1,'Corte: Degradê',156,'2026-08-29 08:16:48'),
(54,30,16,'CREDITO',1,'Corte: Degradê',158,'2026-08-29 08:23:43'),
(55,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',157,'2026-08-29 08:44:19'),
(56,30,16,'CREDITO',1,'Corte: Degradê',159,'2026-08-29 08:48:55'),
(57,30,16,'CREDITO',1,'Corte: Degradê',161,'2026-08-29 09:05:13'),
(58,30,16,'CREDITO',1,'Corte: Degradê',162,'2026-08-29 09:36:26'),
(59,30,16,'CREDITO',1,'Corte: Degradê',164,'2026-08-29 10:44:41'),
(60,35,31,'CREDITO',1,'Corte: BARBA COM TOALHA QUENTE',165,'2026-08-29 14:06:09'),
(61,35,30,'CREDITO',1,'Corte: CORTE COM LUZES',166,'2026-08-29 14:27:20'),
(62,35,31,'CREDITO',1,'Corte: BARBA COM TOALHA QUENTE',171,'2026-08-29 15:29:45'),
(63,35,31,'CREDITO',1,'Corte: PLATINADO',170,'2026-08-29 15:30:37'),
(64,35,30,'CREDITO',1,'Corte: BARBA COM TOALHA QUENTE',173,'2026-08-29 15:46:59'),
(65,35,30,'CREDITO',1,'Corte: CORTE TODO NA TESOURA',174,'2026-08-29 15:51:45'),
(66,35,29,'CREDITO',1,'Corte: BARBA NO VAPOR DE OZONIO',175,'2026-08-29 15:56:55'),
(67,35,29,'CREDITO',1,'Corte: CORTE COM RELAXAMENTO + PLATINADO',167,'2026-08-29 19:13:00'),
(68,35,29,'CREDITO',1,'Corte: BARBA SIMPLES + BARBA NO VAPOR DE OZONIO',169,'2026-08-29 19:13:02'),
(69,35,30,'CREDITO',1,'Corte: BARBA COM TOALHA QUENTE',176,'2026-08-29 20:47:08'),
(70,35,30,'CREDITO',1,'Corte: BARBA COM TOALHA QUENTE',177,'2026-08-29 20:50:29'),
(71,30,16,'CREDITO',1,'Corte: Corte Simples',180,'2026-08-29 21:54:31'),
(72,30,16,'CREDITO',1,'Corte: Corte Simples + Barba',181,'2026-08-29 21:58:48'),
(73,30,16,'CREDITO',1,'Corte: Corte Simples',182,'2026-08-29 22:04:44'),
(74,30,16,'CREDITO',1,'Corte: Degradê',163,'2026-08-29 23:00:21'),
(75,30,16,'CREDITO',1,'Corte: Corte Simples',160,'2026-08-29 23:00:23'),
(76,30,16,'CREDITO',1,'Corte: Escova',183,'2026-08-30 09:16:47'),
(77,30,16,'CREDITO',1,'Corte: Escova',184,'2026-08-30 10:13:04'),
(78,30,16,'CREDITO',1,'Corte: Corte Simples',185,'2026-08-30 10:13:49');
/*!40000 ALTER TABLE `fidelidade_historico` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fidelidade_saldo`
--

DROP TABLE IF EXISTS `fidelidade_saldo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fidelidade_saldo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `saldo_pontos` int(11) DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id` (`tenant_id`,`cliente_id`),
  KEY `tenant_id_2` (`tenant_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fidelidade_saldo`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fidelidade_saldo` WRITE;
/*!40000 ALTER TABLE `fidelidade_saldo` DISABLE KEYS */;
INSERT INTO `fidelidade_saldo` VALUES
(1,1,1,1,'2026-08-20 18:18:33'),
(3,30,16,57,'2026-08-30 10:13:49'),
(4,30,17,2,'2026-08-24 13:36:09'),
(8,30,18,2,'2026-08-25 10:09:00'),
(48,30,19,3,'2026-08-28 18:23:39'),
(60,35,31,3,'2026-08-29 15:30:37'),
(61,35,30,5,'2026-08-29 20:50:29'),
(66,35,29,3,'2026-08-29 19:13:02');
/*!40000 ALTER TABLE `fidelidade_saldo` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `guiche_servicos`
--

DROP TABLE IF EXISTS `guiche_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guiche_servicos` (
  `guiche_id` int(11) NOT NULL,
  `servico_id` int(11) NOT NULL,
  PRIMARY KEY (`guiche_id`,`servico_id`),
  KEY `fk_gs_servico` (`servico_id`),
  CONSTRAINT `fk_gs_guiche` FOREIGN KEY (`guiche_id`) REFERENCES `guiches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gs_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guiche_servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `guiche_servicos` WRITE;
/*!40000 ALTER TABLE `guiche_servicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `guiche_servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `guiches`
--

DROP TABLE IF EXISTS `guiches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guiches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `icone` varchar(10) DEFAULT '⚙️',
  `cor` varchar(7) DEFAULT '#1565C0',
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_guiche_codigo` (`tenant_id`,`codigo`),
  CONSTRAINT `fk_guiches_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guiches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `guiches` WRITE;
/*!40000 ALTER TABLE `guiches` DISABLE KEYS */;
INSERT INTO `guiches` VALUES
(38,30,'01','Barber Ricardo','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 16:08:01'),
(39,30,'02','Barber João','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 16:07:44'),
(40,30,'03','Barber Piu','⚙️','#1565C0',1,'2026-08-22 10:03:43','2026-08-22 10:13:19'),
(59,35,'01','BARBEIRO ISRAEL','⚙️','#1565C0',1,'2026-08-26 15:57:28','2026-08-26 15:57:28'),
(60,35,'02','BARBEIRO MARCOS','⚙️','#1565C0',1,'2026-08-26 15:58:09','2026-08-26 15:58:09'),
(61,35,'03','BARBEIRO LUIS VITOR','⚙️','#1565C0',1,'2026-08-26 15:58:37','2026-08-26 15:59:06'),
(62,35,'04','BARBEIRO YSMAEL','⚙️','#1565C0',1,'2026-08-26 15:59:32','2026-08-26 15:59:32'),
(63,35,'05','BARBEIRO RAY','⚙️','#1565C0',1,'2026-08-26 16:00:13','2026-08-26 16:00:13'),
(64,30,'04','Brandão','⚙️','#1565C0',1,'2026-08-28 08:10:54','2026-08-28 08:10:54');
/*!40000 ALTER TABLE `guiches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `licencas`
--

DROP TABLE IF EXISTS `licencas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `licencas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `chave` varchar(100) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  `uuid` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ATIVA',
  `validade` datetime DEFAULT NULL,
  `ultima_validacao` datetime DEFAULT NULL,
  `offline_dias` int(11) DEFAULT 15,
  `assinatura` text DEFAULT NULL,
  `hardware_id` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_licenca` (`tenant_id`,`chave`),
  CONSTRAINT `fk_licencas_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licencas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `licencas` WRITE;
/*!40000 ALTER TABLE `licencas` DISABLE KEYS */;
INSERT INTO `licencas` VALUES
(17,30,NULL,'FORCE-KEY-2026','1C3E5CE9B707A09D1A80A33D87C1BF30A5F7D05F68D10E628365A99A52AEF125','5579fd18-b48e-473e-a6e1-fb3cf1335700','ATIVA','2027-08-22 00:00:00','2026-08-30 10:38:18',15,'64672622b4fe39f919a24217da7fa2aac74a576af16c21b221d9913d0122a271','174d0c49541eb26014b5f39f1286a04c9f63ba53b396de5b79d5a6522d81a234','2026-08-22 09:49:19'),
(21,35,28,'4A35D050AE2E','3F6AF87BA87ECEBD4A8397D7FBD2C4ADCB814C2AA37700411FF5F223A5A2DFE2','4aa0051b-2af1-44a4-a361-ea063c1aaf02','ATIVA','2027-08-26 11:05:53',NULL,15,'c1ad92e9d04fbba995fc9e33931291efa3464a6633bca473a3232505f1b0ac16','174d0c49541eb26014b5f39f1286a04c9f63ba53b396de5b79d5a6522d81a234','2026-08-26 11:05:53');
/*!40000 ALTER TABLE `licencas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `arquivo` varchar(255) DEFAULT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `executado_em` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `arquivo` (`arquivo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'001_initial.sql','d41d8cd98f00b204e9800998ecf8427e','2026-08-21 14:34:37'),
(2,'003_fix_senhas.sql','d41d8cd98f00b204e9800998ecf8427e','2026-08-21 14:34:37'),
(3,'005_create_servicos.sql','d41d8cd98f00b204e9800998ecf8427e','2026-08-21 14:34:37'),
(4,'006_evolucao_sync.sql','d41d8cd98f00b204e9800998ecf8427e','2026-08-21 14:34:37'),
(5,'007_promo_updates.sql','6bf30df7dda792f189bf9c184668bfff','2026-08-21 14:37:58'),
(6,'008_create_agenda_tables.sql','3f4f8b37af3d0c8199156609d9ab5f74','2026-08-21 19:03:21'),
(7,'009_add_release_windows.sql','c2c7ec41d6d0b9c153097fbde398b163','2026-08-21 19:47:15'),
(8,'010_strict_scheduling_rules.sql','2514fee943b2750a6f143839915f185c','2026-08-21 19:47:15');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operador_guiche`
--

DROP TABLE IF EXISTS `operador_guiche`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operador_guiche` (
  `operador_id` int(11) NOT NULL,
  `guiche_id` int(11) NOT NULL,
  PRIMARY KEY (`operador_id`,`guiche_id`),
  KEY `fk_og_guiche` (`guiche_id`),
  CONSTRAINT `fk_og_guiche` FOREIGN KEY (`guiche_id`) REFERENCES `guiches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_og_operador` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operador_guiche`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operador_guiche` WRITE;
/*!40000 ALTER TABLE `operador_guiche` DISABLE KEYS */;
/*!40000 ALTER TABLE `operador_guiche` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operador_servicos`
--

DROP TABLE IF EXISTS `operador_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operador_servicos` (
  `operador_id` int(11) NOT NULL,
  `servico_id` int(11) NOT NULL,
  PRIMARY KEY (`operador_id`,`servico_id`),
  KEY `fk_os_servico` (`servico_id`),
  CONSTRAINT `fk_os_operador` FOREIGN KEY (`operador_id`) REFERENCES `operadores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_os_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operador_servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operador_servicos` WRITE;
/*!40000 ALTER TABLE `operador_servicos` DISABLE KEYS */;
INSERT INTO `operador_servicos` VALUES
(31,44),
(33,44),
(34,44),
(44,44),
(31,47),
(33,47),
(34,47),
(44,47),
(31,48),
(33,48),
(34,48),
(44,48),
(31,49),
(33,49),
(34,49),
(44,49),
(31,50),
(44,50),
(39,55),
(40,55),
(41,55),
(42,55),
(43,55),
(39,56),
(40,56),
(41,56),
(42,56),
(43,56),
(39,57),
(40,57),
(41,57),
(42,57),
(43,57),
(39,58),
(40,58),
(41,58),
(42,58),
(43,58),
(39,59),
(40,59),
(41,59),
(42,59),
(43,59),
(39,60),
(40,60),
(41,60),
(42,60),
(43,60),
(39,61),
(40,61),
(41,61),
(42,61),
(43,61),
(39,62),
(40,62),
(41,62),
(42,62),
(43,62),
(39,63),
(40,63),
(41,63),
(42,63),
(43,63),
(39,64),
(40,64),
(41,64),
(42,64),
(43,64),
(39,65),
(40,65),
(41,65),
(42,65),
(43,65),
(39,66),
(40,66),
(41,66),
(42,66),
(43,66),
(39,67),
(40,67),
(41,67),
(42,67),
(43,67),
(39,68),
(40,68),
(41,68),
(42,68),
(43,68),
(39,69),
(40,69),
(41,69),
(42,69),
(43,69),
(39,70),
(40,70),
(41,70),
(42,70),
(43,70);
/*!40000 ALTER TABLE `operador_servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operadores`
--

DROP TABLE IF EXISTS `operadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `nivel` enum('ADMIN','GERENTE','OPERADOR') DEFAULT 'OPERADOR',
  `comissao` decimal(5,2) DEFAULT 50.00,
  `guiche_id` int(11) DEFAULT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `prefixo` varchar(5) DEFAULT NULL,
  `foto_url` text DEFAULT NULL,
  `magic_token` varchar(100) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) DEFAULT 'ONLINE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_login` (`tenant_id`,`login`),
  CONSTRAINT `fk_operadores_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operadores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operadores` WRITE;
/*!40000 ALTER TABLE `operadores` DISABLE KEYS */;
INSERT INTO `operadores` VALUES
(30,30,'Administrador Master','admin','$2y$12$0yVHl1Nc7DCrbatIdRaUJ.xwOgPYZDcWSz8mXiS.k2f/rEZ/JMdhC','ADMIN',50.00,0,0,'',NULL,NULL,1,'2026-08-22 09:49:19','2026-08-27 08:46:53','BREAK'),
(31,30,'Ricardo','ricardo','$2y$12$79e6DNN9J4kGrwT80NAkv.WUg7QJFvYZYRzfVfh3n4OWcVQ3i1ha6','OPERADOR',50.00,38,48,'RB','tenants/30/operador_31.png',NULL,1,'2026-08-22 10:03:43','2026-08-30 10:15:15','ONLINE'),
(33,30,'Joâo','joao','$2y$12$I6xG/oV0PG6N.0X2kArd.OAVfbafdOA9DVmqp4k.nwfrqfsFbwZ82','OPERADOR',50.00,39,48,'JO','tenants/30/operador_33.png',NULL,1,'2026-08-22 11:08:54','2026-08-27 20:32:35','ONLINE'),
(34,30,'Piu','piu','$2y$12$6CRxMH2jKazkz0VxCwxqNOt9pFy9P5pZJ5LlhSY2mqCIjk0fxcXBS','OPERADOR',50.00,40,48,'PI','tenants/30/operador_34.png',NULL,1,'2026-08-22 11:09:35','2026-08-27 08:29:04','ONLINE'),
(38,35,'Administrador Israel','admin','$2y$12$1moAEd4IbFEg1d55Uf6VGOiZkYrk4/leY3L07EBDS9lHg2URLyemW','ADMIN',50.00,0,0,'',NULL,NULL,1,'2026-08-26 11:05:57','2026-08-28 14:41:47','ONLINE'),
(39,35,'ISRAEL','israel26','$2y$12$6asrGnpw5p8Mr/Ew9tV1jOew1O0X4KJ5TOAbyaIgpboKZoEoyWXSS','OPERADOR',40.00,59,68,'IS','tenants/35/operador_39.png',NULL,1,'2026-08-26 16:07:20','2026-08-29 14:01:20','ONLINE'),
(40,35,'MARCOS','marcos26','$2y$12$xxUrB/I2GeswY8aSwisUre4X1xSsZxN8/ZfHDJuTyUIoPJJyfm9r6','OPERADOR',40.00,60,68,'MA','tenants/35/operador_40.png',NULL,1,'2026-08-26 16:09:47','2026-08-28 14:44:47','ONLINE'),
(41,35,'LUIS VITOR','luis26','$2y$12$jpxC5yrLnFPbuX8OTHP5BOzIwI/sTQ0XJfMu9jyHmnBtf8R6QgDdq','OPERADOR',40.00,61,68,'LV','tenants/35/operador_41.png',NULL,1,'2026-08-26 16:13:57','2026-08-28 14:43:39','ONLINE'),
(42,35,'YSMAEL','ysmael26','$2y$12$klvFJN1Tu74dnlYFi7aZfOjxGQbMaTpFuo8t.P3tyb0iVO.SuLjYq','OPERADOR',40.00,62,68,'YS','tenants/35/operador_42.png',NULL,1,'2026-08-26 16:16:37','2026-08-29 15:23:08','ONLINE'),
(43,35,'RAY','ray26','$2y$12$h0BYEZWarPQnrVkJ231f4uRcQQ6qfgd1VTdWKwxFDjgaDmxE9SqGO','OPERADOR',40.00,63,68,'RY','tenants/35/operador_43.png',NULL,1,'2026-08-26 16:20:12','2026-08-28 14:45:22','ONLINE'),
(44,30,'Ricardo Brandão','brandao','$2y$12$T5FO9qqBI.RC59A8yk8JbehZ/MY1lMX5PL64nMgpBR/pGnGBNATXW','OPERADOR',50.00,64,48,'B','',NULL,1,'2026-08-26 18:38:42','2026-08-28 08:12:48','ONLINE');
/*!40000 ALTER TABLE `operadores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promocoes`
--

DROP TABLE IF EXISTS `promocoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` varchar(50) DEFAULT NULL,
  `imagem` text DEFAULT NULL,
  `ordem` int(11) DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_promocoes_tenant` (`tenant_id`),
  CONSTRAINT `fk_promocoes_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocoes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promocoes` WRITE;
/*!40000 ALTER TABLE `promocoes` DISABLE KEYS */;
INSERT INTO `promocoes` VALUES
(6,30,'Cerveja Heineken Long Neck 330ml','20% OFF','R$ 19,90','CCA23C49.jpg',0,1,'2026-08-22 11:07:33','2026-08-22 11:07:33'),
(7,30,'Cerveja Budweiser, American Lager, Long Neck 330ml','','R$ 18,90','D71AC7C2.jpg',1,1,'2026-08-22 11:07:52','2026-08-22 11:07:52'),
(8,30,'Vitamina C 500mg 30 Comprimidos Neo Química','20% OFF','R$ 14 , 99','437319C3.webp',2,1,'2026-08-22 11:11:36','2026-08-24 22:28:59'),
(10,35,'PASTA PREMIUM MANTEIGA DE KARITE','fixação extra forte / para todos os cabelos','R$ 40,00','84C55EB4.webp',7,1,'2026-08-28 16:15:27','2026-08-29 16:07:32'),
(11,35,'FOX FOR MEM / CREME MODELADOR EFEITO TEIA','(PASTA EFEITO TEIA ) fixaçao suave hidrataçao dos fios','R$ 40,00','8A069B67.webp',7,1,'2026-08-28 16:36:12','2026-08-28 16:36:12'),
(12,35,'FOX FOR MEM / CERA HAIR MODELADORA CARAMELO','fixação extra forte para todos os cabelos','R$ 40,00','80FFE381.webp',6,1,'2026-08-28 16:40:00','2026-08-29 16:09:52'),
(13,35,'FOX FOR MEM LOÇAO POS BARBA','REFRESCA E ACALMA A PELE','60,00','C2E7196B.webp',2,1,'2026-08-28 16:41:31','2026-08-28 16:41:31'),
(14,35,'FOX FOR MEM / BALM PARA BARBA','HIDRATA E REDUZ O FRIZZ NOS FIOS REBELDES DA BARBA','60,00','001D4F66.webp',7,1,'2026-08-28 16:50:34','2026-08-28 16:50:34'),
(15,35,'SPRAY FIXADOR','FIXAÇAO & DURABILIDADE','65,00','3F0B4C49.webp',2,1,'2026-08-28 16:53:58','2026-08-28 16:53:58');
/*!40000 ALTER TABLE `promocoes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `senhas`
--

DROP TABLE IF EXISTS `senhas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `senhas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `cliente_uuid` varchar(64) DEFAULT NULL,
  `servico_id` int(11) DEFAULT NULL,
  `guiche_id` int(11) DEFAULT NULL,
  `operador_id` int(11) DEFAULT NULL,
  `device_id` varchar(100) DEFAULT NULL,
  `codigo` varchar(20) NOT NULL,
  `numero` int(11) NOT NULL,
  `prefixo` varchar(5) NOT NULL,
  `nome_cliente` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'AGUARDANDO',
  `tipo_atendimento` varchar(20) DEFAULT 'NORMAL',
  `data_agendamento` datetime DEFAULT NULL,
  `cancel_token` varchar(32) DEFAULT NULL,
  `pagamento_status` varchar(20) DEFAULT 'PENDENTE',
  `pagamento_id` varchar(100) DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT 0.00,
  `valor_total` decimal(10,2) DEFAULT 0.00,
  `servicos_desc` text DEFAULT NULL,
  `atendente` varchar(255) DEFAULT NULL,
  `atendente_nome` varchar(255) DEFAULT NULL,
  `emitida_em` datetime DEFAULT current_timestamp(),
  `chamada_em` datetime DEFAULT NULL,
  `finalizada_em` datetime DEFAULT NULL,
  `sincronizado` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cliente_id` int(11) DEFAULT 0,
  `pix_qr_code` text DEFAULT NULL,
  `pix_qr_base64` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `idx_tenant_status` (`tenant_id`,`status`),
  KEY `idx_tenant_created` (`tenant_id`,`created_at`),
  KEY `idx_senhas_status` (`status`),
  KEY `idx_senhas_uuid` (`uuid`),
  CONSTRAINT `fk_senhas_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senhas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `senhas` WRITE;
/*!40000 ALTER TABLE `senhas` DISABLE KEYS */;
INSERT INTO `senhas` VALUES
(84,30,'cfaabfbbb68207b0ae0e22afe87d6479','CLI-7ZL3R48BW',47,38,31,NULL,'AGD001',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','NORMAL','2026-08-22 12:00:00','0F50B31B','PAGO','STATIC_1787407948',0.00,70.00,'Degradê','Ricardo Brandão',NULL,'2026-08-22 12:00:00','2026-08-22 11:17:16','2026-08-22 11:24:12',0,'2026-08-22 11:12:28','2026-08-22 11:24:12',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',NULL),
(85,30,'23f3dc9d6cfe941c21f579a15bd2771e','24a6e14332b3376ae12fa64a06a63eda',47,39,33,'dev-1787079976163','JO001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787414723',0.00,70.00,'Degradê','JOÃO',NULL,'2026-08-22 13:05:23','2026-08-22 13:06:47','2026-08-22 13:08:10',0,'2026-08-22 13:05:23','2026-08-22 13:10:50',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(86,30,'0172951e6932aa2cabcf0163d3b568e5','CLI-JDKJB3E8F',49,39,33,NULL,'AGD003',0,'G','RICARDO','7191077018','FINALIZADA','NORMAL','2026-08-22 14:00:00','83D3F958','PAGO','STATIC_1787415142',0.00,35.00,'Corte Simples + Barba','JOÃO',NULL,'2026-08-22 14:00:00','2026-08-22 13:18:03','2026-08-22 13:39:32',0,'2026-08-22 13:12:22','2026-08-22 16:23:48',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',NULL),
(87,30,'4aa30d8f9b7abb652fcd432ce89ba772','2b29e2eccf4dc9e623286ee0562db603',47,38,31,'dev-1787434871949','RB001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787434883',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-22 18:41:23','2026-08-22 18:55:13','2026-08-22 18:55:30',0,'2026-08-22 18:41:23','2026-08-22 18:55:30',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(88,30,'1ce0ef937aa05bd0f909f39f926d4fa0','cb07b8c40db06e76a2b4180a0378b3c1',47,38,31,'dev-1787079925702','RB002',2,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787438623',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-22 19:43:43','2026-08-22 19:44:28','2026-08-22 19:44:49',0,'2026-08-22 19:43:43','2026-08-22 19:44:49',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(89,30,'c53d8666432aa401dc86d8064d23af10','7b91b6365d50875ab01bc2a3b69041bf',49,38,31,'7b0b5f3b1d1ab6c8cc8add53ee2dd98d','RB003',3,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787439026',0.00,35.00,'Corte Simples + Barba','Brandão',NULL,'2026-08-22 19:50:26','2026-08-22 19:50:48','2026-08-22 19:51:04',0,'2026-08-22 19:50:26','2026-08-22 19:51:04',15,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(90,30,'4b5c3e9301015738b00e87be1fad8799','e1222598da8ab9cc6f2e4cef1ac5b444',49,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB004',4,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787451176',0.00,35.00,'Corte Simples + Barba','Brandão',NULL,'2026-08-22 23:12:56','2026-08-22 23:14:47','2026-08-22 23:15:37',0,'2026-08-22 23:12:56','2026-08-22 23:15:37',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(91,30,'2666efe309fb3ad474381ce39daa25fc','ef91a0255e42218d7f7e6020ccf633a4',47,1,31,'897e38fcad2749656f41846c229d03ef','RB005',5,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787453005',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-22 23:43:25','2026-08-22 23:43:38','2026-08-22 23:43:49',0,'2026-08-22 23:43:25','2026-08-25 09:11:17',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(92,30,'5272bb387f38d064847bf36c76175ef9','df52ce25feb43ae153aeab48e9582c43',49,1,31,'897e38fcad2749656f41846c229d03ef','RB006',6,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787453786',0.00,35.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-22 23:56:26','2026-08-22 23:56:37','2026-08-22 23:56:58',0,'2026-08-22 23:56:26','2026-08-22 23:56:58',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(93,30,'2232f4ca209515ee32c4db646764d89b','54369c833f4ef692b916d87a625cc8d5',47,1,31,'897e38fcad2749656f41846c229d03ef','RB001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787454093',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-23 00:01:33','2026-08-23 00:01:37','2026-08-23 00:01:44',0,'2026-08-23 00:01:33','2026-08-23 00:01:44',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(94,30,'7d78fb81d58aae28c32c20993d020f2a','d69924bceac8e05aaab0f5d67c8389ef',49,1,31,'897e38fcad2749656f41846c229d03ef','RB002',2,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787454882',0.00,35.00,'Corte Simples + Barba','Brandão',NULL,'2026-08-23 00:14:42','2026-08-23 00:14:49','2026-08-23 00:14:57',0,'2026-08-23 00:14:42','2026-08-23 00:14:57',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(95,30,'d9673b9d8955041bb09d2bf133654283','a58fc4139a8824b04e73ce5d5636fefa',47,1,31,'897e38fcad2749656f41846c229d03ef','RB003',3,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787493181',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-23 10:53:01','2026-08-23 10:53:17','2026-08-23 10:53:25',0,'2026-08-23 10:53:01','2026-08-23 10:53:25',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(96,30,'b63638c6a3fa0779b4bb215adb981e1d','0ec3a65fbbc35269b8e0f1f6bd48d6ed',47,1,31,'897e38fcad2749656f41846c229d03ef','RB004',4,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787494390',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-23 11:13:10','2026-08-23 11:13:15','2026-08-23 11:13:23',0,'2026-08-23 11:13:10','2026-08-23 11:13:23',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(97,30,'9d9715579549ee5e9fdda5a6104f7db8','f67b0658877d0cc2675e71819e4212a1',47,1,33,'897e38fcad2749656f41846c229d03ef','JO001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787496985',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-23 11:56:25','2026-08-23 11:56:31','2026-08-23 11:56:39',0,'2026-08-23 11:56:25','2026-08-23 11:56:39',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(98,30,'d04d312cc8fa344b585060bdb73e0cc3','08563ed1d57ecd35e589b4fe0484e999',48,38,31,'dev-1787519091306','RB005',5,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787519103',0.00,45.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-23 18:05:03','2026-08-23 18:05:44','2026-08-23 18:06:16',0,'2026-08-23 18:05:03','2026-08-23 18:06:16',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540545.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304972D',''),
(99,30,'b8b5aa354e08fb5a99669d053968c856','a59882a28099cdd922b1b26c9ae17c59',49,38,31,'b7b548094d74a2f7a8b6b203427cd5db','RB001',1,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787587081',0.00,50.00,'Barba + Corte Simples + Barba','Sistema',NULL,'2026-08-24 12:58:01','2026-08-24 12:59:23','2026-08-24 13:00:02',0,'2026-08-24 12:58:01','2026-08-24 13:00:02',17,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540550.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304D83F',''),
(100,30,'1c176ae25109d2784c04b80cc7e42914','b7b548094d74a2f7a8b6b203427cd5db',49,38,31,NULL,'AGD002',0,'G','CLAUDIONOR SANTANA DOS SANTOS','71984850615','FINALIZADA','NORMAL','2026-08-24 14:30:00','B6A5EB42','PAGO','STATIC_1787588411',0.00,105.00,'Degradê + Corte Simples + Barba','Sistema',NULL,'2026-08-24 14:30:00','2026-08-24 13:23:34','2026-08-24 13:23:46',0,'2026-08-24 13:20:11','2026-08-24 13:36:09',17,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406105.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304CC9D',NULL),
(101,30,'3c77adc10dc56aea5b77e1207087e5ae','CLI-JDKJB3E8F',50,38,31,NULL,'AGD003',0,'G','EMILY SOUZA','7191077012','FINALIZADA','NORMAL','2026-08-24 15:00:00','A10FF419','PAGO','STATIC_1787589598',0.00,100.00,'Escova','Sistema',NULL,'2026-08-24 15:00:00','2026-08-24 13:55:53','2026-08-24 13:56:03',0,'2026-08-24 13:39:58','2026-08-24 13:56:03',0,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',NULL),
(102,30,'1708d259505f7afffcd05fccb35922e9','d10c655b14ee80ca23ad642e97e120ae',50,38,31,'dev-1787155730007','RB002',2,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787589883',0.00,100.00,'Escova','Sistema',NULL,'2026-08-24 13:44:43','2026-08-24 13:45:17','2026-08-24 13:45:45',0,'2026-08-24 13:44:43','2026-08-24 13:45:45',0,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(103,30,'abe874c3cb7de33d9a5c3af52d182b6a','eed0525d31a9abdf0e817ab87b26fe76',47,38,31,'7b0b5f3b1d1ab6c8cc8add53ee2dd98d','RB003',3,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787614371',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-24 20:32:51','2026-08-24 20:33:59','2026-08-24 20:34:32',0,'2026-08-24 20:32:51','2026-08-24 20:34:32',15,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(104,30,'01de3dc488ff255c8962a80f642ec4a2','3d283133aa2ae7827614a8890a31b5f2',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB004',4,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787617460',0.00,100.00,'Escova','Sistema',NULL,'2026-08-24 21:24:20','2026-08-24 21:44:43','2026-08-24 21:44:53',0,'2026-08-24 21:24:20','2026-08-24 21:44:53',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(105,30,'1f8d6a6bb325babdf0a20c358289e773','a7ee464874b73de6c6ba7af0c6b9de9e',47,38,31,'4cd5d8d481a34e7ae7ac6422af34071b','RB005',5,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787617869',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-24 21:31:09','2026-08-24 21:44:59','2026-08-24 21:45:02',0,'2026-08-24 21:31:09','2026-08-24 22:41:57',18,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(106,30,'94dc38a3762a856a94eaf46b36b7584c','caf0712c606d33a143da2ea8e2c1ca02',47,NULL,31,NULL,'AGD008',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','CANCELADO','NORMAL','2026-08-25 08:00:00','5B26F19B','PENDENTE','STATIC_1787618045',0.00,70.00,'Degradê',NULL,NULL,'2026-08-25 08:00:00',NULL,NULL,0,'2026-08-24 21:34:05','2026-08-24 21:35:02',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',NULL),
(107,30,'f2d2474b6d0c5720064f310ce32725ba','4cd5d8d481a34e7ae7ac6422af34071b',49,38,31,NULL,'AGD009',0,'G','ITA PALOMA','71991007491','FINALIZADA','NORMAL','2026-08-25 10:00:00','72B70661','PAGO','STATIC_1787618251',0.00,35.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-25 10:00:00','2026-08-25 10:08:31','2026-08-25 10:09:02',0,'2026-08-24 21:37:31','2026-08-25 10:09:02',18,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',NULL),
(108,30,'fa5dc5297f7e9b761af2493edffb1587','a79b78762e4c4f93ed22d81e8a41802d',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB006',6,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787619282',0.00,100.00,'Escova','Sistema',NULL,'2026-08-24 21:54:41','2026-08-24 22:43:11','2026-08-24 22:43:21',0,'2026-08-24 21:54:41','2026-08-25 09:11:15',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(109,30,'a535d855985c3f959d090a9e4045e1c8','caf0712c606d33a143da2ea8e2c1ca02',50,38,31,NULL,'AGD011',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','NORMAL','2026-08-24 22:30:00','758DB5A4','PAGO','STATIC_1787619374',0.00,100.00,'Escova','Sistema',NULL,'2026-08-24 22:30:00','2026-08-24 22:45:08','2026-08-24 22:45:13',0,'2026-08-24 21:56:14','2026-08-25 09:11:13',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',NULL),
(110,30,'9e315db4dbacd9f1a7c1e2dcd4a2088f','28f4d4a7eb91051e60272d5731221095',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787669221',0.00,100.00,'Escova','Brandão',NULL,'2026-08-25 11:47:01','2026-08-25 11:47:13','2026-08-25 11:47:19',0,'2026-08-25 11:47:01','2026-08-25 11:47:19',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(111,30,'b69498486df428611cffc62732d399c1','01a93e5178978d87b7eec16f12b17b3e',48,38,31,'abf8bb7e-50a8-4d6d-8847-3ea3a169dd09','RB002',2,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787678118',0.00,15.00,'Barba','Sistema',NULL,'2026-08-25 14:15:18','2026-08-25 14:54:13','2026-08-25 14:54:24',0,'2026-08-25 14:15:18','2026-08-25 14:54:24',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(112,30,'868a52829265124442b62b76c7f1ff9d','caf0712c606d33a143da2ea8e2c1ca02',44,38,31,NULL,'AGD003',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','NORMAL','2026-08-25 15:30:00','5CB45A6D','PAGO',NULL,0.00,0.00,'Corte Simples (VIP)','Sistema',NULL,'2026-08-25 15:30:00','2026-08-25 14:54:28','2026-08-25 14:54:45',0,'2026-08-25 14:51:34','2026-08-25 14:54:45',16,NULL,NULL),
(113,30,'f2ec8f6b70839ba6151aa04ff4746620','a0b092dfcf7a5c19e6d29e514bd1f529',48,38,31,'caf0712c606d33a143da2ea8e2c1ca02','BAR001',1,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787690514',0.00,15.00,'Barba','Sistema',NULL,'2026-08-25 17:41:54','2026-08-25 17:46:18','2026-08-25 17:46:26',0,'2026-08-25 17:41:54','2026-08-25 17:46:26',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(114,30,'427243fc5998a1670a1f13412d4605ad','6431ca6eda20f3e8950af2c6708c74c2',48,38,31,'15013942-80ce-4d78-92ea-c5423f7a03e2','BAR002',2,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787690724',0.00,15.00,'Barba','Sistema',NULL,'2026-08-25 17:45:24','2026-08-25 17:46:27','2026-08-25 17:46:35',0,'2026-08-25 17:45:24','2026-08-25 17:46:35',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(115,30,'e643c2b099cb0fbe41c61438060e856b','96945329b4fcfc384f98fe0fcc11279b',49,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB003',3,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787703868',0.00,35.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-25 21:24:28','2026-08-25 21:30:18','2026-08-25 21:30:27',0,'2026-08-25 21:24:28','2026-08-25 21:30:27',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(116,30,'4b926ff052b1067ddf978c17bcbe18c7','181a73a0a3cdd91cd41ef010239cbaaf',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB004',4,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787704085',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-25 21:28:05','2026-08-25 21:30:35','2026-08-25 21:30:42',0,'2026-08-25 21:28:05','2026-08-25 21:30:42',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(117,30,'8e8ab0ab97c9278e12bc3cdc2dd31ba5','5f23f12ff2b85c2b212e8791415287a6',47,38,31,'77ef0f73-2f55-4513-b62d-799fe696e468','RB005',5,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787704148',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-25 21:29:08','2026-08-25 21:30:46','2026-08-25 21:30:55',0,'2026-08-25 21:29:08','2026-08-25 21:30:55',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(118,30,'8cf350ba83e9ea7de8b843e394d09db9','e97568aab0bee2aa54ce49fef7f5cdb1',49,38,31,'15013942-80ce-4d78-92ea-c5423f7a03e2','RB006',6,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787704175',0.00,35.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-25 21:29:35','2026-08-25 21:31:02','2026-08-25 21:31:09',0,'2026-08-25 21:29:35','2026-08-25 21:31:09',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(119,30,'f63b086887d71d36933de1c19c593b81','21d8f52a44ba9ca37bfa77363d6f1047',47,39,33,'caf0712c606d33a143da2ea8e2c1ca02','JO001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787704598',0.00,70.00,'Degradê','Joâo',NULL,'2026-08-25 21:36:38','2026-08-25 22:24:58','2026-08-25 22:25:12',0,'2026-08-25 21:36:38','2026-08-25 22:25:12',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(120,30,'bfa039b17361b66a002251946b933127','b9c09e3070cc3edc9be919d253d22dd1',48,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB007',7,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787705170',0.00,15.00,'Barba','Sistema',NULL,'2026-08-25 21:46:10','2026-08-25 22:00:04','2026-08-25 22:00:26',0,'2026-08-25 21:46:10','2026-08-25 22:00:26',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(121,30,'c332b029c41d6ad18496307fb7354db6','9e67982c1a72fb88aacbc2c2f3fbce21',48,39,33,'caf0712c606d33a143da2ea8e2c1ca02','BAR001',1,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787706328',0.00,15.00,'Barba','Joâo',NULL,'2026-08-25 22:05:28','2026-08-25 22:25:16','2026-08-25 22:25:39',0,'2026-08-25 22:05:28','2026-08-25 22:25:39',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(122,30,'5d3c346da2001036bad0efd07fdcf276','f5cc18e8d103519ead0c06864e2b46b9',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','DEG001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787708142',0.00,70.00,'Degradê','Piu',NULL,'2026-08-25 22:35:42','2026-08-25 22:59:22','2026-08-25 22:59:39',0,'2026-08-25 22:35:42','2026-08-25 22:59:39',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(123,30,'6e9343543e3218da40fe192bd067603d','b36214e0bab20cc2f784efbc46434410',44,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI001',1,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787709265',0.00,30.00,'Corte Simples','Piu',NULL,'2026-08-25 22:54:25','2026-08-25 22:59:44','2026-08-25 22:59:50',0,'2026-08-25 22:54:25','2026-08-25 22:59:50',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(124,30,'dda3a11f9e8745118aa5cc1e7ad6c96d','a7cfcd28bc7cb72655c7bd80c87c3a33',48,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI002',2,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787709485',0.00,15.00,'Barba','Piu',NULL,'2026-08-25 22:58:05','2026-08-25 22:59:54','2026-08-25 23:00:06',0,'2026-08-25 22:58:05','2026-08-25 23:00:06',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(125,30,'18a86dc25931c886480cabd165bc5099','e1f4f9615579b9887221f04730b9b6fb',48,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB008',8,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787710121',0.00,15.00,'Barba','Brandão',NULL,'2026-08-25 23:08:41','2026-08-25 23:28:53','2026-08-25 23:29:02',0,'2026-08-25 23:08:41','2026-08-25 23:29:02',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(126,30,'b56d0df1c1dc3e710c94c549a0bf84e2','5b4515d6d2586369a0d4073445625e27',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB009',9,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787710548',0.00,100.00,'Escova','Brandão',NULL,'2026-08-25 23:15:48','2026-08-25 23:29:07','2026-08-25 23:29:20',0,'2026-08-25 23:15:48','2026-08-25 23:29:20',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(127,30,'9096abee133c95429fb3ba2b6cdc2019','d0a730a676b9d1a133cc2af22f8f2538',47,NULL,31,'caf0712c606d33a143da2ea8e2c1ca02','RB010',10,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787712226',0.00,70.00,'Degradê',NULL,NULL,'2026-08-25 23:43:46',NULL,'2026-08-26 08:36:12',0,'2026-08-25 23:43:46','2026-08-26 19:03:33',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(128,30,'ab801d393522cb0606796bf6093d7dc6','87573e93a075b71f10bb45023387d46f',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787743533',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-26 08:25:33','2026-08-26 08:25:59','2026-08-26 08:27:10',0,'2026-08-26 08:25:33','2026-08-26 08:27:10',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(129,30,'de33eb7d54c5ecc6e2f3747dcb7b36ab','40725cff7b382f2371e51257b47e7fb0',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB002',2,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787744574',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-26 08:42:54','2026-08-26 08:47:07','2026-08-26 08:47:11',0,'2026-08-26 08:42:54','2026-08-26 08:47:11',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(130,30,'44e0c567db2cc10fb47d1484361019d7','77489ead8713615d051e907d94e8d106',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB003',3,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787752307',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-26 10:51:47','2026-08-26 10:55:19','2026-08-26 10:55:29',0,'2026-08-26 10:51:47','2026-08-26 10:55:29',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(131,30,'39212fbf5d55dca08ffe0468af95c372','eddd153630a5cfe80dde217360b3f164',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB004',4,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787752705',0.00,100.00,'Escova','Brandão',NULL,'2026-08-26 10:58:25','2026-08-26 11:06:31','2026-08-26 11:06:58',0,'2026-08-26 10:58:25','2026-08-26 11:06:58',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(132,30,'adaba774918ca376cab4dcbd9ecad561','8a9d986fcdc36256a95599c0a7c42156',47,39,33,'caf0712c606d33a143da2ea8e2c1ca02','JO001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787752711',0.00,70.00,'Degradê','Joâo',NULL,'2026-08-26 10:58:31','2026-08-26 11:14:59','2026-08-26 11:15:15',0,'2026-08-26 10:58:31','2026-08-26 11:15:15',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(135,35,'58dfaa4fa938c214ad34248fdce609ad','CLI-6PL1RWFLH',68,59,39,NULL,'AGD001',0,'G','VICTOR CARVALHO','71983600449','FINALIZADA','NORMAL','2026-08-26 19:00:00','797C270D','PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-26 19:00:00','2026-08-26 18:24:43','2026-08-26 18:26:01',0,'2026-08-26 17:44:26','2026-08-26 18:27:30',0,NULL,NULL),
(136,35,'1acb65f81985257ce861f6c80e3bfb0d','8d526089669e201fee0c13b3646fa162',69,59,39,'d3853ea0-75d2-4033-8f49-9465bc6122e6','IS001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,70.00,'BARBA NO VAPOR DE OZONIO','ISRAEL',NULL,'2026-08-26 18:43:53','2026-08-26 18:44:55','2026-08-26 18:45:49',0,'2026-08-26 18:43:53','2026-08-26 18:45:49',0,NULL,NULL),
(137,35,'f361f215b6a76a9c0db91e3a1b2c6268','0031bc63c7f0149b919f8564c9ef42c9',68,59,39,'d3853ea0-75d2-4033-8f49-9465bc6122e6','IS001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-27 14:20:06','2026-08-27 14:22:02','2026-08-27 15:06:01',0,'2026-08-27 14:20:06','2026-08-29 20:58:10',0,NULL,NULL),
(138,30,'6073d3031e167d97e44828a9164e0451','4caba4c1b09972d1b2cafdb747fc52c4',47,NULL,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'DEG','',NULL,'AGUARDANDO','NORMAL',NULL,NULL,'PENDENTE','STATIC_1787875935',0.00,70.00,'Degradê',NULL,NULL,'2026-08-27 21:12:15',NULL,NULL,0,'2026-08-27 21:12:15','2026-08-27 21:12:15',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(139,30,'b3be2ecf7c53ca8ffd5d9fb3d4c96289','5b16055ea932cd1d01598763c17ceef2',50,NULL,31,'','RB002',2,'S','Ricardo',NULL,'AGUARDANDO','NORMAL',NULL,NULL,'PENDENTE','STATIC_1787877208',0.00,100.00,'',NULL,NULL,'2026-08-27 21:33:28',NULL,NULL,0,'2026-08-27 21:33:28','2026-08-27 21:33:28',0,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(140,30,'af024ceea5326a0411dfad7b702df71c','caf0712c606d33a143da2ea8e2c1ca02',44,38,31,NULL,'AGD001',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','NORMAL','2026-08-28 08:30:00','552A6BCE','PAGO',NULL,0.00,0.00,'Corte Simples (VIP)','Brandão',NULL,'2026-08-28 08:30:00','2026-08-28 08:13:03','2026-08-28 08:14:22',0,'2026-08-28 07:44:38','2026-08-28 08:14:22',16,NULL,NULL),
(141,30,'f5e980154edc9305f5b7d0aa83e2bd24','f504121379822baf4e592f8b1738e2bc',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787914884',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-28 08:01:24','2026-08-28 08:11:24','2026-08-28 08:12:58',0,'2026-08-28 08:01:24','2026-08-28 08:12:58',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(142,30,'3029fb6ae6dd1bfd968b57a85398999f','caf0712c606d33a143da2ea8e2c1ca02',44,38,31,NULL,'AGD003',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-28 09:00:00','181BE5CE','PAGO',NULL,0.00,0.00,'Corte Simples (VIP)','Brandão',NULL,'2026-08-28 09:00:00','2026-08-28 08:50:24','2026-08-28 08:51:15',0,'2026-08-28 08:18:25','2026-08-28 08:51:15',16,NULL,NULL),
(143,30,'1c6f805d3fe2eecae6229baceef8555c','caf0712c606d33a143da2ea8e2c1ca02',44,38,31,NULL,'AGD004',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-28 09:30:00','3F4DFD22','PAGO',NULL,0.00,0.00,'Corte Simples (VIP)','Brandão',NULL,'2026-08-28 09:30:00','2026-08-28 08:57:38','2026-08-28 09:05:07',0,'2026-08-28 08:56:43','2026-08-28 09:05:07',16,NULL,NULL),
(144,30,'ea4ab9aeaa91eacd9a29cffd5f843b0e','caf0712c606d33a143da2ea8e2c1ca02',44,38,31,NULL,'AGD005',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-28 10:00:00','84F3D167','PAGO','STATIC_1787919422',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-28 10:00:00','2026-08-28 09:21:58','2026-08-28 09:22:09',0,'2026-08-28 09:17:02','2026-08-28 09:22:09',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',NULL),
(145,30,'84bab1d0ac25d2012b6c9c684cf0b3c3','9ef02a0ae94bea9cc8bd09c176e213c2',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB002',2,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787919540',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-28 09:19:00','2026-08-28 09:21:46','2026-08-28 09:21:52',0,'2026-08-28 09:19:00','2026-08-28 09:21:52',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(146,30,'f56e414227bdedb5aaa1213b9c7e2085','caf0712c606d33a143da2ea8e2c1ca02',50,38,31,NULL,'AGD007',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-28 10:30:00','2D5C9CFD','PAGO','STATIC_1787919782',0.00,100.00,'Escova','Brandão',NULL,'2026-08-28 10:30:00','2026-08-28 09:31:21','2026-08-28 09:31:34',0,'2026-08-28 09:23:02','2026-08-28 09:31:34',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',NULL),
(147,30,'665e5c41ebed62ae2e54664102ec3599','caf0712c606d33a143da2ea8e2c1ca02',48,38,31,NULL,'AGD008',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-28 11:00:00','D1FFB5D1','PAGO','STATIC_1787920365',0.00,15.00,'Barba','Brandão',NULL,'2026-08-28 11:00:00','2026-08-28 09:38:18','2026-08-28 09:38:21',0,'2026-08-28 09:32:45','2026-08-28 09:38:21',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',NULL),
(148,30,'c51045e6bbfa7f01ae767038bb843116','702c976c7592453c880ef473fd0f832b',48,38,31,'5d8ae23d-e468-41cb-9482-db0cc84cd5f7','RB003',3,'BAR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PENDENTE','STATIC_1787921000',0.00,15.00,'Barba','Brandão',NULL,'2026-08-28 09:43:20','2026-08-28 09:50:24','2026-08-28 09:50:28',0,'2026-08-28 09:43:20','2026-08-28 09:50:28',0,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540515.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63048749',''),
(149,35,'964eab4b5cd41aa2c2381b66c86bb1e8','e60e8310d3d66137442ef2f0d46d1733',68,62,42,'d3853ea0-75d2-4033-8f49-9465bc6122e6','YS001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','YSMAEL',NULL,'2026-08-28 15:25:10','2026-08-28 15:25:20','2026-08-28 15:25:39',0,'2026-08-28 15:25:10','2026-08-29 20:58:08',0,NULL,NULL),
(150,35,'b87ee75b2324d74fda0df67e2a6130c4','6c38444eacc6d70f679d5848304b8456',70,NULL,42,'d3853ea0-75d2-4033-8f49-9465bc6122e6','YS002',2,'S','',NULL,'AGUARDANDO','NORMAL',NULL,NULL,'PENDENTE',NULL,0.00,80.00,'LIMPEZA DE PELE',NULL,NULL,'2026-08-28 15:27:18',NULL,NULL,0,'2026-08-28 15:27:18','2026-08-28 15:27:18',0,NULL,NULL),
(151,30,'c84ac3cc897eee54d9246048afbec858','22c269b7c1471e65fd4ac1a7f09dc00b',49,38,31,NULL,'AGD010',0,'G','YASMIN PRYCILLA','71988394069','FINALIZADA','AGENDAMENTO','2026-08-28 18:30:00','958DF573','PAGO','STATIC_1787950551',0.00,35.00,'Corte Simples + Barba','Sistema',NULL,'2026-08-28 18:30:00','2026-08-28 18:04:13','2026-08-28 18:04:18',0,'2026-08-28 17:55:51','2026-08-28 18:04:18',19,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',NULL),
(152,30,'4538bfb415e52254910cc7bfe9c4a2e6','22c269b7c1471e65fd4ac1a7f09dc00b',47,38,31,NULL,'AGD011',0,'G','RICARDO  BRANDãO','71988394069','FINALIZADA','AGENDAMENTO','2026-08-28 19:00:00','47562EC1','PAGO','STATIC_1787951133',0.00,70.00,'Degradê','Sistema',NULL,'2026-08-28 19:00:00','2026-08-28 18:06:29','2026-08-28 18:07:01',0,'2026-08-28 18:05:33','2026-08-28 18:07:01',19,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',NULL),
(153,30,'a73026c21c003cf9d2aced28b67200de','22c269b7c1471e65fd4ac1a7f09dc00b',50,38,31,NULL,'AGD012',0,'G','RICARDO  BRANDãO','71988394069','FINALIZADA','AGENDAMENTO','2026-08-28 19:30:00','B38E6B16','PAGO','STATIC_1787952057',0.00,100.00,'Escova','Sistema',NULL,'2026-08-28 19:30:00','2026-08-28 18:23:23','2026-08-28 18:23:43',0,'2026-08-28 18:20:57','2026-08-28 18:23:43',19,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',NULL),
(154,30,'9722fb9115fb4f5536404df5ac52a7b6','caf0712c606d33a143da2ea8e2c1ca02',49,38,31,NULL,'AGD013',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-29 08:00:00','6079EA6C','PAGO','STATIC_1787971567',0.00,35.00,'Corte Simples + Barba','Brandão',NULL,'2026-08-29 08:00:00','2026-08-29 08:16:22','2026-08-29 08:16:31',0,'2026-08-28 23:46:07','2026-08-29 08:16:31',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',NULL),
(155,30,'b02e5592988998037c55129e5544ab78','b6f09a3eef5066815baa214057932fcb',49,39,33,'caf0712c606d33a143da2ea8e2c1ca02','JO001',1,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1787972484',0.00,35.00,'Corte Simples + Barba','Joâo',NULL,'2026-08-29 00:01:24','2026-08-29 00:12:55','2026-08-29 08:11:47',0,'2026-08-29 00:01:24','2026-08-29 08:11:47',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(156,30,'7855c8e7b486776f29b8bd9c1ad10f85','74c16a8ac79520b6e6ca76d7b6f1f7ca',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788001778',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-29 08:09:38','2026-08-29 08:18:47','2026-08-29 08:18:49',0,'2026-08-29 08:09:38','2026-08-29 08:18:49',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(157,30,'8bc1c48684d1cd34bd7a720a8327c885','05185fdc08b6b5b41d4b424111f63807',49,39,33,'caf0712c606d33a143da2ea8e2c1ca02','JO002',2,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788002412',0.00,35.00,'Corte Simples + Barba','Joâo',NULL,'2026-08-29 08:20:12','2026-08-29 08:44:03','2026-08-29 08:45:57',0,'2026-08-29 08:20:12','2026-08-29 08:45:57',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(158,30,'3f341d54abd422e1328d9ddc07724c3e','89154c36918ea34ac9595082d8351bfa',47,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB002',2,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788002450',0.00,70.00,'Degradê','Brandão',NULL,'2026-08-29 08:20:50','2026-08-29 08:23:46','2026-08-29 08:23:47',0,'2026-08-29 08:20:50','2026-08-29 08:23:47',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(159,30,'2eff497af7789e206d6ec3bf1328c690','3142b500f4c68b9fdda1df07cb0238a0',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI001',1,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788003766',0.00,70.00,'Degradê','Piu',NULL,'2026-08-29 08:42:46','2026-08-29 08:48:21','2026-08-29 08:48:58',0,'2026-08-29 08:42:46','2026-08-29 08:48:58',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(160,30,'e1f54e7087e3ec5e652ccbd48e4b809d','6e55110f127afed9074a4d7d2aa04180',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB003',3,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788003786',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-29 08:43:06','2026-08-29 08:43:39','2026-08-29 08:43:47',0,'2026-08-29 08:43:06','2026-08-29 23:00:23',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(161,30,'29aa858086854814fcdaf9d6c8e63790','37eb88cec690fff0a7509783414c99f4',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI002',2,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788004862',0.00,70.00,'Degradê','Piu',NULL,'2026-08-29 09:01:02','2026-08-29 09:01:06','2026-08-29 09:05:15',0,'2026-08-29 09:01:02','2026-08-29 09:05:15',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(162,30,'e31246da69d025d46e52a62f050079ba','50d2623ac2fac92d3244b517c5358b2a',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI003',3,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788006190',0.00,70.00,'Degradê','Piu',NULL,'2026-08-29 09:23:10','2026-08-29 09:34:03','2026-08-29 09:36:32',0,'2026-08-29 09:23:10','2026-08-29 09:36:32',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(163,30,'847e1775bc04715974eb0bf9d0829b94','ade2be671ed63f61097e8a02277a57a4',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI004',4,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788010710',0.00,70.00,'Degradê','Piu',NULL,'2026-08-29 10:38:30','2026-08-29 10:43:37','2026-08-29 10:43:40',0,'2026-08-29 10:38:30','2026-08-29 23:00:21',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(164,30,'e14e063e5ab5ecb1f4a985fe51f919e6','6f2801c741d5c5e0c469c232a731ea29',47,40,34,'caf0712c606d33a143da2ea8e2c1ca02','PI005',5,'DEG','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788011061',0.00,70.00,'Degradê','Piu',NULL,'2026-08-29 10:44:21','2026-08-29 10:44:29','2026-08-29 10:45:51',0,'2026-08-29 10:44:21','2026-08-29 10:45:51',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540570.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630482A2',''),
(165,35,'94ebcdb6a1deadeac8ed15d56208efd7','5efd68f69239637a25bfa5f4778af955',68,59,39,NULL,'AGD001',0,'G','ISRAEL SILVA','71991050259','FINALIZADA','AGENDAMENTO','2026-08-29 14:00:00','2B9E3D70','PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-29 14:00:00','2026-08-29 14:07:05','2026-08-29 14:08:07',0,'2026-08-29 13:15:53','2026-08-29 14:08:07',31,NULL,NULL),
(166,35,'c7e7e61bba516e98797e85bef520c44f','83e3343e6eaba23e1564c9e4c054476f',63,59,39,NULL,'AGD002',0,'G','MARCIO RICARDO BRANDãO DE JESUS','71991077018','FINALIZADA','AGENDAMENTO','2026-08-29 15:00:00','2BDCAC38','PAGO',NULL,0.00,170.00,'CORTE COM LUZES','ISRAEL',NULL,'2026-08-29 15:00:00','2026-08-29 14:26:59','2026-08-29 14:27:22',0,'2026-08-29 13:40:27','2026-08-29 14:27:22',30,NULL,NULL),
(167,35,'09cffa100a29dc2205a6c1a72c50632a','cca7b8cd1e33004e7d62a11021e76cce',62,59,39,NULL,'AGD003',0,'G','VICTOR HUGO CARVALHO NOGUEIRA DOS SANTOS','71983600449','FINALIZADA','AGENDAMENTO','2026-08-29 16:00:00','391098D6','PAGO',NULL,0.00,300.00,'CORTE COM RELAXAMENTO + PLATINADO','ISRAEL',NULL,'2026-08-29 16:00:00','2026-08-29 14:36:16','2026-08-29 14:36:52',0,'2026-08-29 13:47:28','2026-08-29 19:13:00',29,NULL,NULL),
(168,35,'0bc0185aeaf70765dec6c4ae3fd94637','8b65e6397229eb0c2021aea65e3cf4f6',68,59,39,'8f4443d9-cd76-4224-99fa-d5b2beb9be9d','IS001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-29 13:57:09','2026-08-29 14:08:36','2026-08-29 14:09:22',0,'2026-08-29 13:57:09','2026-08-29 14:09:22',0,NULL,NULL),
(169,35,'95416fda647c69f7fd4eb835f741264d','2e62c3168edd401bf9ae4594b7111a42',69,59,39,'cca7b8cd1e33004e7d62a11021e76cce','IS002',2,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,110.00,'BARBA SIMPLES + BARBA NO VAPOR DE OZONIO','ISRAEL',NULL,'2026-08-29 14:33:31','2026-08-29 14:36:11','2026-08-29 14:36:14',0,'2026-08-29 14:33:31','2026-08-29 19:13:02',29,NULL,NULL),
(170,35,'d4c3dbe18b3943e0372e53e8310a3a42','5efd68f69239637a25bfa5f4778af955',64,59,39,NULL,'AGD006',0,'G','ISRAEL SILVA','71991050259','FINALIZADA','AGENDAMENTO','2026-08-29 17:00:00','3EEBBCD2','PAGO',NULL,0.00,200.00,'PLATINADO','Sistema',NULL,'2026-08-29 17:00:00','2026-08-29 15:29:59','2026-08-29 15:30:41',0,'2026-08-29 15:05:36','2026-08-29 15:30:41',31,NULL,NULL),
(171,35,'a5d2c423647e73dd6c00d754ce8494d0','f0fdf480b0c465527802607b77ea9dc0',68,59,39,'5efd68f69239637a25bfa5f4778af955','IS003',3,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','Sistema',NULL,'2026-08-29 15:26:23','2026-08-29 15:29:06','2026-08-29 15:29:53',0,'2026-08-29 15:26:23','2026-08-29 15:29:53',31,NULL,NULL),
(172,35,'164e4605e5832ec04d45b63c7d0f80ec','169ebcac1d669521e48fe95d3e9e43f7',59,62,42,'','YS001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,60.00,'CORTE COM LAVAGEM','Sistema',NULL,'2026-08-29 15:34:17','2026-08-29 15:34:24','2026-08-29 15:34:40',0,'2026-08-29 15:34:17','2026-08-29 15:34:40',0,NULL,NULL),
(173,35,'754bd842f9720e29f9e23aec606ffe67','8ad7e425d517fae153e48b258a687a6a',68,59,39,'83e3343e6eaba23e1564c9e4c054476f','IS004',4,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-29 15:44:41','2026-08-29 15:46:46','2026-08-29 15:47:01',0,'2026-08-29 15:44:41','2026-08-29 15:47:01',30,NULL,NULL),
(174,35,'c96f59e217512f7684dce24120ad79cc','d5c30db6887cff541690d1f645a62776',57,59,39,'83e3343e6eaba23e1564c9e4c054476f','IS005',5,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'CORTE TODO NA TESOURA','ISRAEL',NULL,'2026-08-29 15:51:08','2026-08-29 15:51:34','2026-08-29 15:51:46',0,'2026-08-29 15:51:08','2026-08-29 15:51:46',30,NULL,NULL),
(175,35,'ea06a5262bd7a362089c0487aa060413','1fc11891a9726d535e9510d39b077e94',69,59,39,'cca7b8cd1e33004e7d62a11021e76cce','IS006',6,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,70.00,'BARBA NO VAPOR DE OZONIO','ISRAEL',NULL,'2026-08-29 15:53:21','2026-08-29 15:56:46','2026-08-29 15:57:00',0,'2026-08-29 15:53:21','2026-08-29 15:57:00',29,NULL,NULL),
(176,35,'622fa6447775ae07ad514f33b620d681','2f2545a20571c599020c47a945264ddd',68,59,39,'83e3343e6eaba23e1564c9e4c054476f','IS007',7,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-29 16:53:53','2026-08-29 16:54:03','2026-08-29 20:47:12',0,'2026-08-29 16:53:53','2026-08-29 20:47:12',30,NULL,NULL),
(177,35,'3947135e6a0069348fa549aaa5020154','444c4462e9bcb2a6b32412d8ee99da69',68,59,39,'83e3343e6eaba23e1564c9e4c054476f','IS008',8,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,50.00,'BARBA COM TOALHA QUENTE','ISRAEL',NULL,'2026-08-29 20:48:04','2026-08-29 20:50:21','2026-08-29 20:50:32',0,'2026-08-29 20:48:04','2026-08-29 20:50:32',30,NULL,NULL),
(178,35,'45557bb6098bbc4a40582b14fbb9b892','3da038551781ab129f1fabd6c6f8dd79',69,59,39,'8f4443d9-cd76-4224-99fa-d5b2beb9be9d','IS009',9,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,70.00,'BARBA NO VAPOR DE OZONIO','ISRAEL',NULL,'2026-08-29 21:19:23','2026-08-29 21:20:41','2026-08-29 21:21:28',0,'2026-08-29 21:19:23','2026-08-29 21:21:28',0,NULL,NULL),
(179,35,'4599937f5367bba155a41f76cd2ce8b3','f93919ae03bbdde5fff62edcc5a14e78',67,59,39,'8f4443d9-cd76-4224-99fa-d5b2beb9be9d','IS010',10,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO',NULL,0.00,40.00,'BARBA SIMPLES','ISRAEL',NULL,'2026-08-29 21:21:07','2026-08-29 21:21:39','2026-08-29 21:22:29',0,'2026-08-29 21:21:07','2026-08-29 21:22:29',0,NULL,NULL),
(180,30,'ebfb5bb04c1db930324a5960610c90e4','914b438193c061c4b962a6fd2ee5534a',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB004',4,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788051202',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-29 21:53:22','2026-08-29 21:54:15','2026-08-29 21:54:37',0,'2026-08-29 21:53:22','2026-08-29 21:54:37',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(181,30,'35e30f99d89b21fd6e5f97d51fdbc2d6','43c80b58876c385d0126b24979c59516',49,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB005',5,'COR','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788051470',0.00,35.00,'Corte Simples + Barba','Brandão',NULL,'2026-08-29 21:57:50','2026-08-29 21:58:31','2026-08-29 21:58:53',0,'2026-08-29 21:57:50','2026-08-29 21:58:53',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540535.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***6304DDD4',''),
(182,30,'1170f43e53ca65f3e723acc0276d8d7b','50f2977d723002e493bdeea981a9be8c',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB006',6,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788051834',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-29 22:03:54','2026-08-29 22:04:23','2026-08-29 22:04:48',0,'2026-08-29 22:03:54','2026-08-29 22:04:48',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798',''),
(183,30,'7a0c9c57584d1443abe586c4e612c84b','fd7c2e9069fac53605db95220685b688',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB001',1,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788092109',0.00,100.00,'Escova','Brandão',NULL,'2026-08-30 09:15:09','2026-08-30 09:16:25','2026-08-30 09:17:27',0,'2026-08-30 09:15:09','2026-08-30 09:17:27',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(184,30,'c9804c8bb708db2cb89e9d38b7a0b241','a702fb07aff08c0d7beea5ca2970757b',50,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB002',2,'S','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788095388',0.00,100.00,'Escova','Brandão',NULL,'2026-08-30 10:09:48','2026-08-30 10:12:54','2026-08-30 10:13:14',0,'2026-08-30 10:09:48','2026-08-30 10:13:14',16,'00020101021126360014br.gov.bcb.pix0114+55719910770185204000053039865406100.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***630426D1',''),
(185,30,'e6cd0c217e2f9079359bfc05579ea4a8','975f0ed24a1478bb67094cb56f3cdad8',44,38,31,'caf0712c606d33a143da2ea8e2c1ca02','RB003',3,'CRS','',NULL,'FINALIZADA','NORMAL',NULL,NULL,'PAGO','STATIC_1788095440',0.00,30.00,'Corte Simples','Brandão',NULL,'2026-08-30 10:10:40','2026-08-30 10:13:31','2026-08-30 10:13:56',0,'2026-08-30 10:10:40','2026-08-30 10:13:56',16,'00020101021126360014br.gov.bcb.pix0114+5571991077018520400005303986540530.005802BR5917BRANDAO TECH LITE6008BRASILIA62070503***63043798','');
/*!40000 ALTER TABLE `senhas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `servicos`
--

DROP TABLE IF EXISTS `servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `prefixo` varchar(5) NOT NULL,
  `icone` varchar(10) DEFAULT '?',
  `cor` varchar(7) DEFAULT '#1565C0',
  `ordem` int(11) DEFAULT 0,
  `tempo_medio` int(11) DEFAULT 10,
  `preco` decimal(10,2) DEFAULT 0.00,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tenant_servico_slug` (`tenant_id`,`slug`),
  UNIQUE KEY `idx_tenant_servico_codigo` (`tenant_id`,`codigo`),
  CONSTRAINT `fk_servicos_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `servicos` WRITE;
/*!40000 ALTER TABLE `servicos` DISABLE KEYS */;
INSERT INTO `servicos` VALUES
(44,30,'1','Corte Simples','Máquina e Tesoura','CRS','✂️','#1565c0',1,10,30.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(45,30,'02','Vacinação','Vacinação','VAC','💉','#1565c0',2,10,0.00,0,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(46,30,'E','EXAMES','exames','EX','🩺','#c19c15',1,10,0.00,0,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(47,30,'2','Degradê','Taper Fade','DEG','👨🏼‍🦰','#010509',0,10,70.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(48,30,'1786887154869','Barba','barba','BAR','🧔🏾‍♂️','#1db4ff',0,30,15.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(49,30,'1786890923218','Corte Simples + Barba','corte-simples-+-barba','COR','✂️🧔🏾‍♂️','#1db4ff',0,45,35.00,1,'2026-08-22 10:03:43','2026-08-22 10:03:43'),
(50,30,'1787589413037','Escova','escova-','S','✂️','#ff00ff',0,30,100.00,1,'2026-08-24 13:37:43','2026-08-24 13:37:43'),
(55,35,'1787769173348','CORTE TODO NA MAQUINA','corte-todo-na-maquina','S','✂️','#05a5f5',0,30,40.00,1,'2026-08-26 15:34:47','2026-08-26 15:38:38'),
(56,35,'1787769327894','CORTE MAQUINA + TESOURA','corte-maquina-+-tesoura','S','✂️','#1db4ff',0,40,45.00,1,'2026-08-26 15:36:14','2026-08-29 15:10:28'),
(57,35,'1787769522651','CORTE TODO NA TESOURA','corte-todo-na-tesoura-','S','✂️','#1db4ff',0,40,50.00,1,'2026-08-26 15:40:22','2026-08-26 15:40:22'),
(58,35,'1787769648205','CORTE INFANTIL','corte-infantil','S','✂️','#1db4ff',0,50,50.00,1,'2026-08-26 15:41:20','2026-08-26 15:41:20'),
(59,35,'1787769687605','CORTE COM LAVAGEM','corte-com-lavagem-','S','✂️','#1db4ff',0,40,60.00,1,'2026-08-26 15:42:10','2026-08-26 15:42:10'),
(60,35,'1787769736304','CORTE COM HIDRATACAO','corte-com-hidratacao-','S','✂️','#1db4ff',0,50,80.00,1,'2026-08-26 15:43:29','2026-08-26 15:43:29'),
(61,35,'1787769813916','CORTE COM PIGMENTACAO','corte-com-pigmentacao-','S','✂️','#1db4ff',0,60,100.00,1,'2026-08-26 15:44:49','2026-08-26 15:44:49'),
(62,35,'1787769896463','CORTE COM RELAXAMENTO','corte-com-relaxamento','S','✂️','#2c87b5',0,60,100.00,1,'2026-08-26 15:45:52','2026-08-26 15:45:52'),
(63,35,'1787769965151','CORTE COM LUZES','corte-com-luzes-','S','✂️','#1db4ff',0,40,170.00,1,'2026-08-26 15:47:31','2026-08-26 15:47:31'),
(64,35,'1787770056097','PLATINADO','platinado-','S','✂️','#1db4ff',0,40,200.00,1,'2026-08-26 15:48:29','2026-08-26 15:48:29'),
(65,35,'1787770121240','SOBRANCELHA','sobrancelha','S','✂️','#1db4ff',0,10,30.00,1,'2026-08-26 15:49:30','2026-08-26 15:49:30'),
(66,35,'1787770175177','PE DE CABELO','pe-de-cabelo','S','✂️','#1db4ff',0,15,30.00,1,'2026-08-26 15:50:12','2026-08-26 15:50:12'),
(67,35,'1787770217132','BARBA SIMPLES','barba-simples','S','✂️','#1db4ff',0,20,40.00,1,'2026-08-26 15:51:09','2026-08-26 15:51:09'),
(68,35,'1787770275351','BARBA COM TOALHA QUENTE','barba-com-toalha-quente-','S','✂️','#1db4ff',0,30,50.00,1,'2026-08-26 15:51:46','2026-08-26 15:51:46'),
(69,35,'1787770308871','BARBA NO VAPOR DE OZONIO','barba-no-vapor-de-ozonio','S','✂️','#1db4ff',0,40,70.00,1,'2026-08-26 15:52:38','2026-08-26 15:52:38'),
(70,35,'1787770362206','LIMPEZA DE PELE','limpeza-de-pele-','S','✂️','#1db4ff',0,20,80.00,1,'2026-08-26 15:53:58','2026-08-26 15:53:58');
/*!40000 ALTER TABLE `servicos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sync_queue`
--

DROP TABLE IF EXISTS `sync_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `evento` varchar(50) NOT NULL,
  `entidade` varchar(50) NOT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `prioridade` int(11) DEFAULT 0,
  `sincronizado` tinyint(1) DEFAULT 0,
  `tentativas` int(11) DEFAULT 0,
  `ultimo_erro` text DEFAULT NULL,
  `processado_em` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sync_tenant` (`tenant_id`),
  KEY `idx_sync_status` (`sincronizado`),
  CONSTRAINT `fk_sync_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_queue`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sync_queue` WRITE;
/*!40000 ALTER TABLE `sync_queue` DISABLE KEYS */;
INSERT INTO `sync_queue` VALUES
(102,30,'CHAMAR','senha',84,'{\"senha\":\"AGD001\",\"codigo\":\"AGD001\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Babrber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-22 11:17:16'),
(103,30,'CHAMAR','senha',85,'{\"senha\":\"JO001\",\"codigo\":\"JO001\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Babrber João\"}',0,0,0,NULL,NULL,'2026-08-22 13:06:47'),
(104,30,'CHAMAR','senha',86,'{\"senha\":\"AGD003\",\"codigo\":\"AGD003\",\"nome_cliente\":\"RICARDO\",\"guiche\":39,\"guiche_nome\":\"Babrber João\"}',0,0,0,NULL,NULL,'2026-08-22 13:18:03'),
(105,30,'CHAMAR','senha',87,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-22 18:55:13'),
(106,30,'CHAMAR','senha',88,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-22 19:44:28'),
(107,30,'CHAMAR','senha',89,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-22 19:50:48'),
(108,30,'CHAMAR','senha',90,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-22 23:14:47'),
(109,30,'CHAMAR','senha',91,'{\"senha\":\"RB005\",\"codigo\":\"RB005\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-22 23:43:38'),
(110,30,'CHAMAR','senha',92,'{\"senha\":\"RB006\",\"codigo\":\"RB006\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-22 23:56:37'),
(111,30,'CHAMAR','senha',93,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-23 00:01:37'),
(112,30,'CHAMAR','senha',94,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-23 00:14:49'),
(113,30,'CHAMAR','senha',95,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-23 10:53:17'),
(114,30,'CHAMAR','senha',96,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-23 11:13:15'),
(115,30,'CHAMAR','senha',97,'{\"senha\":\"JO001\",\"codigo\":\"JO001\",\"nome_cliente\":\"\",\"guiche\":1,\"guiche_nome\":\"Guichê 1\"}',0,0,0,NULL,NULL,'2026-08-23 11:56:31'),
(116,30,'CHAMAR','senha',98,'{\"senha\":\"RB005\",\"codigo\":\"RB005\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-23 18:05:44'),
(117,30,'CHAMAR','senha',99,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 12:59:23'),
(118,30,'CHAMAR','senha',100,'{\"senha\":\"AGD002\",\"codigo\":\"AGD002\",\"nome_cliente\":\"CLAUDIONOR SANTANA DOS SANTOS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 13:23:34'),
(119,30,'CHAMAR','senha',102,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 13:45:17'),
(120,30,'CHAMAR','senha',101,'{\"senha\":\"AGD003\",\"codigo\":\"AGD003\",\"nome_cliente\":\"EMILY SOUZA\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 13:55:53'),
(121,30,'CHAMAR','senha',103,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 20:33:59'),
(122,30,'CHAMAR','senha',104,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 21:44:43'),
(123,30,'CHAMAR','senha',105,'{\"senha\":\"RB005\",\"codigo\":\"RB005\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 21:44:59'),
(124,30,'CHAMAR','senha',108,'{\"senha\":\"RB006\",\"codigo\":\"RB006\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 22:43:11'),
(125,30,'CHAMAR','senha',109,'{\"senha\":\"AGD011\",\"codigo\":\"AGD011\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-24 22:45:08'),
(126,30,'CHAMAR','senha',107,'{\"senha\":\"AGD009\",\"codigo\":\"AGD009\",\"nome_cliente\":\"ITA PALOMA\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 10:08:31'),
(127,30,'CHAMAR','senha',110,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 11:47:13'),
(128,30,'CHAMAR','senha',111,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 14:54:13'),
(129,30,'CHAMAR','senha',112,'{\"senha\":\"AGD003\",\"codigo\":\"AGD003\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 14:54:28'),
(130,30,'CHAMAR','senha',113,'{\"senha\":\"BAR001\",\"codigo\":\"BAR001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 17:46:18'),
(131,30,'CHAMAR','senha',114,'{\"senha\":\"BAR002\",\"codigo\":\"BAR002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 17:46:27'),
(132,30,'CHAMAR','senha',115,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 21:30:18'),
(133,30,'CHAMAR','senha',116,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 21:30:35'),
(134,30,'CHAMAR','senha',117,'{\"senha\":\"RB005\",\"codigo\":\"RB005\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 21:30:46'),
(135,30,'CHAMAR','senha',118,'{\"senha\":\"RB006\",\"codigo\":\"RB006\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 21:31:02'),
(136,30,'CHAMAR','senha',120,'{\"senha\":\"RB007\",\"codigo\":\"RB007\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 22:00:04'),
(137,30,'CHAMAR','senha',119,'{\"senha\":\"JO001\",\"codigo\":\"JO001\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Barber João\"}',0,0,0,NULL,NULL,'2026-08-25 22:24:58'),
(138,30,'CHAMAR','senha',121,'{\"senha\":\"BAR001\",\"codigo\":\"BAR001\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Barber João\"}',0,0,0,NULL,NULL,'2026-08-25 22:25:16'),
(139,30,'CHAMAR','senha',122,'{\"senha\":\"DEG001\",\"codigo\":\"DEG001\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-25 22:59:22'),
(140,30,'CHAMAR','senha',123,'{\"senha\":\"PI001\",\"codigo\":\"PI001\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-25 22:59:44'),
(141,30,'CHAMAR','senha',124,'{\"senha\":\"PI002\",\"codigo\":\"PI002\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-25 22:59:54'),
(142,30,'CHAMAR','senha',125,'{\"senha\":\"RB008\",\"codigo\":\"RB008\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 23:28:53'),
(143,30,'CHAMAR','senha',126,'{\"senha\":\"RB009\",\"codigo\":\"RB009\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-25 23:29:07'),
(144,30,'CHAMAR','senha',128,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-26 08:25:59'),
(145,30,'CHAMAR','senha',129,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-26 08:47:07'),
(146,30,'CHAMAR','senha',130,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-26 10:55:19'),
(147,30,'CHAMAR','senha',131,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-26 11:06:31'),
(148,30,'CHAMAR','senha',132,'{\"senha\":\"JO001\",\"codigo\":\"JO001\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Barber João\"}',0,0,0,NULL,NULL,'2026-08-26 11:14:59'),
(149,35,'CHAMAR','senha',135,'{\"senha\":\"AGD001\",\"codigo\":\"AGD001\",\"nome_cliente\":\"VICTOR CARVALHO\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-26 18:24:43'),
(150,35,'CHAMAR','senha',136,'{\"senha\":\"IS001\",\"codigo\":\"IS001\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-26 18:44:55'),
(151,35,'CHAMAR','senha',137,'{\"senha\":\"IS001\",\"codigo\":\"IS001\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-27 14:22:02'),
(152,30,'CHAMAR','senha',141,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 08:11:24'),
(153,30,'CHAMAR','senha',140,'{\"senha\":\"AGD001\",\"codigo\":\"AGD001\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 08:13:03'),
(154,30,'CHAMAR','senha',142,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD003\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 08:50:24'),
(155,30,'CHAMAR','senha',143,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD004\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 08:57:38'),
(156,30,'CHAMAR','senha',145,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 09:21:46'),
(157,30,'CHAMAR','senha',144,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD005\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 09:21:58'),
(158,30,'CHAMAR','senha',146,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD007\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 09:31:21'),
(159,30,'CHAMAR','senha',147,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD008\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 09:38:18'),
(160,30,'CHAMAR','senha',148,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 09:50:11'),
(161,30,'CHAMAR','senha',148,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-28 09:50:24'),
(162,35,'CHAMAR','senha',149,'{\"senha\":\"YS001\",\"codigo\":\"YS001\",\"nome_cliente\":\"\",\"guiche\":62,\"guiche_nome\":\"BARBEIRO YSMAEL\"}',0,0,0,NULL,NULL,'2026-08-28 15:25:20'),
(163,30,'CHAMAR','senha',151,'{\"senha\":\"YASMIN PRYCILLA\",\"codigo\":\"AGD010\",\"nome_cliente\":\"YASMIN PRYCILLA\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 18:03:50'),
(164,30,'CHAMAR','senha',151,'{\"senha\":\"YASMIN PRYCILLA\",\"codigo\":\"AGD010\",\"nome_cliente\":\"YASMIN PRYCILLA\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-28 18:04:13'),
(165,30,'CHAMAR','senha',152,'{\"senha\":\"RICARDO  BRANDãO\",\"codigo\":\"AGD011\",\"nome_cliente\":\"RICARDO  BRANDãO\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 18:06:29'),
(166,30,'CHAMAR','senha',153,'{\"senha\":\"RICARDO  BRANDãO\",\"codigo\":\"AGD012\",\"nome_cliente\":\"RICARDO  BRANDãO\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-28 18:22:10'),
(167,30,'CHAMAR','senha',153,'{\"senha\":\"RICARDO  BRANDãO\",\"codigo\":\"AGD012\",\"nome_cliente\":\"RICARDO  BRANDãO\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-28 18:22:28'),
(168,30,'CHAMAR','senha',153,'{\"senha\":\"RICARDO  BRANDãO\",\"codigo\":\"AGD012\",\"nome_cliente\":\"RICARDO  BRANDãO\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-28 18:22:34'),
(169,30,'CHAMAR','senha',153,'{\"senha\":\"RICARDO  BRANDãO\",\"codigo\":\"AGD012\",\"nome_cliente\":\"RICARDO  BRANDãO\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-28 18:23:23'),
(170,30,'CHAMAR','senha',155,'{\"senha\":\"JO001\",\"codigo\":\"JO001\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Barber João\"}',0,0,0,NULL,NULL,'2026-08-29 00:12:55'),
(171,30,'CHAMAR','senha',154,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD013\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 08:15:47'),
(172,30,'CHAMAR','senha',154,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD013\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:16:15'),
(173,30,'CHAMAR','senha',154,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD013\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:16:22'),
(174,30,'CHAMAR','senha',156,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 08:16:36'),
(175,30,'CHAMAR','senha',156,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:18:47'),
(176,30,'CHAMAR','senha',158,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 08:22:02'),
(177,30,'CHAMAR','senha',158,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:22:24'),
(178,30,'CHAMAR','senha',158,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:23:46'),
(179,30,'CHAMAR','senha',160,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 08:43:12'),
(180,30,'CHAMAR','senha',160,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 08:43:39'),
(181,30,'CHAMAR','senha',157,'{\"senha\":\"JO002\",\"codigo\":\"JO002\",\"nome_cliente\":\"\",\"guiche\":39,\"guiche_nome\":\"Barber João\"}',0,0,0,NULL,NULL,'2026-08-29 08:44:03'),
(182,30,'CHAMAR','senha',159,'{\"senha\":\"PI001\",\"codigo\":\"PI001\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-29 08:48:21'),
(183,30,'CHAMAR','senha',161,'{\"senha\":\"PI002\",\"codigo\":\"PI002\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-29 09:01:06'),
(184,30,'CHAMAR','senha',162,'{\"senha\":\"PI003\",\"codigo\":\"PI003\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-29 09:34:03'),
(185,30,'CHAMAR','senha',163,'{\"senha\":\"PI004\",\"codigo\":\"PI004\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-29 10:43:07'),
(186,30,'CHAMAR','senha',163,'{\"senha\":\"PI004\",\"codigo\":\"PI004\",\"nome_cliente\":\"\",\"guiche\":\"03\"}',0,0,0,NULL,NULL,'2026-08-29 10:43:37'),
(187,30,'CHAMAR','senha',164,'{\"senha\":\"PI005\",\"codigo\":\"PI005\",\"nome_cliente\":\"\",\"guiche\":40,\"guiche_nome\":\"Barber Piu\"}',0,0,0,NULL,NULL,'2026-08-29 10:44:29'),
(188,35,'CHAMAR','senha',165,'{\"senha\":\"ISRAEL SILVA\",\"codigo\":\"AGD001\",\"nome_cliente\":\"ISRAEL SILVA\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 14:05:46'),
(189,35,'CHAMAR','senha',165,'{\"senha\":\"ISRAEL SILVA\",\"codigo\":\"AGD001\",\"nome_cliente\":\"ISRAEL SILVA\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:07:05'),
(190,35,'CHAMAR','senha',168,'{\"senha\":\"IS001\",\"codigo\":\"IS001\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 14:08:36'),
(191,35,'CHAMAR','senha',166,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD002\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 14:26:33'),
(192,35,'CHAMAR','senha',166,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD002\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:26:49'),
(193,35,'CHAMAR','senha',166,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD002\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:26:54'),
(194,35,'CHAMAR','senha',166,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD002\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:26:56'),
(195,35,'CHAMAR','senha',166,'{\"senha\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"codigo\":\"AGD002\",\"nome_cliente\":\"MARCIO RICARDO BRANDãO DE JESUS\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:26:59'),
(196,35,'CHAMAR','senha',169,'{\"senha\":\"IS002\",\"codigo\":\"IS002\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 14:33:50'),
(197,35,'CHAMAR','senha',169,'{\"senha\":\"IS002\",\"codigo\":\"IS002\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:36:06'),
(198,35,'CHAMAR','senha',169,'{\"senha\":\"IS002\",\"codigo\":\"IS002\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 14:36:11'),
(199,35,'CHAMAR','senha',167,'{\"senha\":\"VICTOR HUGO CARVALHO NOGUEIRA DOS SANTOS\",\"codigo\":\"AGD003\",\"nome_cliente\":\"VICTOR HUGO CARVALHO NOGUEIRA DOS SANTOS\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 14:36:16'),
(200,35,'CHAMAR','senha',171,'{\"senha\":\"IS003\",\"codigo\":\"IS003\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:29:06'),
(201,35,'CHAMAR','senha',170,'{\"senha\":\"ISRAEL SILVA\",\"codigo\":\"AGD006\",\"nome_cliente\":\"ISRAEL SILVA\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:29:59'),
(202,35,'CHAMAR','senha',172,'{\"senha\":\"YS001\",\"codigo\":\"YS001\",\"nome_cliente\":\"\",\"guiche\":62,\"guiche_nome\":\"BARBEIRO YSMAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:34:24'),
(203,35,'CHAMAR','senha',173,'{\"senha\":\"IS004\",\"codigo\":\"IS004\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:46:46'),
(204,35,'CHAMAR','senha',174,'{\"senha\":\"IS005\",\"codigo\":\"IS005\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:51:34'),
(205,35,'CHAMAR','senha',175,'{\"senha\":\"IS006\",\"codigo\":\"IS006\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 15:56:46'),
(206,35,'CHAMAR','senha',176,'{\"senha\":\"IS007\",\"codigo\":\"IS007\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 16:54:03'),
(207,35,'CHAMAR','senha',177,'{\"senha\":\"IS008\",\"codigo\":\"IS008\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 20:49:48'),
(208,35,'CHAMAR','senha',177,'{\"senha\":\"IS008\",\"codigo\":\"IS008\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 20:50:21'),
(209,35,'CHAMAR','senha',178,'{\"senha\":\"IS009\",\"codigo\":\"IS009\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 21:20:14'),
(210,35,'CHAMAR','senha',178,'{\"senha\":\"IS009\",\"codigo\":\"IS009\",\"nome_cliente\":\"\",\"guiche\":\"01\"}',0,0,0,NULL,NULL,'2026-08-29 21:20:41'),
(211,35,'CHAMAR','senha',179,'{\"senha\":\"IS010\",\"codigo\":\"IS010\",\"nome_cliente\":\"\",\"guiche\":59,\"guiche_nome\":\"BARBEIRO ISRAEL\"}',0,0,0,NULL,NULL,'2026-08-29 21:21:39'),
(212,30,'CHAMAR','senha',180,'{\"senha\":\"RB004\",\"codigo\":\"RB004\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 21:54:15'),
(213,30,'CHAMAR','senha',181,'{\"senha\":\"RB005\",\"codigo\":\"RB005\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 21:58:31'),
(214,30,'CHAMAR','senha',182,'{\"senha\":\"RB006\",\"codigo\":\"RB006\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-29 22:04:23'),
(215,30,'CHAMAR','senha',183,'{\"senha\":\"RB001\",\"codigo\":\"RB001\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-30 09:16:25'),
(216,30,'CHAMAR','senha',184,'{\"senha\":\"RB002\",\"codigo\":\"RB002\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-30 10:12:54'),
(217,30,'CHAMAR','senha',185,'{\"senha\":\"RB003\",\"codigo\":\"RB003\",\"nome_cliente\":\"\",\"guiche\":38,\"guiche_nome\":\"Barber Ricardo\"}',0,0,0,NULL,NULL,'2026-08-30 10:13:31');
/*!40000 ALTER TABLE `sync_queue` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_info`
--

DROP TABLE IF EXISTS `system_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `installation_uuid` varchar(100) NOT NULL,
  `empresa_uuid` varchar(100) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `versao` varchar(20) NOT NULL,
  `build` varchar(50) DEFAULT NULL,
  `ambiente` varchar(20) DEFAULT 'PRODUCAO',
  `created_at` datetime DEFAULT current_timestamp(),
  `last_sync` datetime DEFAULT NULL,
  `php_version` varchar(50) DEFAULT NULL,
  `mariadb_version` varchar(50) DEFAULT NULL,
  `schema_version` int(11) DEFAULT 2,
  `last_heartbeat` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sysinfo_tenant` (`tenant_id`),
  CONSTRAINT `fk_sysinfo_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_info`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_info` WRITE;
/*!40000 ALTER TABLE `system_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_info` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` enum('ATIVO','SUSPENSO','BLOQUEADO') DEFAULT 'ATIVO',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES
(30,'5579fd18-b48e-473e-a6e1-fb3cf1335700','lite','VM - BANCADA','ATIVO','2026-08-22 09:49:19','2026-08-22 09:49:19'),
(35,'4aa0051b-2af1-44a4-a361-ea063c1aaf02','paradaobrigatoriavilas','Parada Obrigatória Vilas','ATIVO','2026-08-26 11:05:53','2026-08-26 11:15:11');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'bt_enterprise_saas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-30 10:38:25
